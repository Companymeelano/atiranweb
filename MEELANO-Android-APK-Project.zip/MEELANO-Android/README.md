# MEELANO Android

نسخه Android قابل نصب برای MEELANO با رابط PWA لوکس و Responsive موجود.

## معماری
- Android native shell (Java + WebView)
- PWA/Backend واقعی روی HTTPS
- احراز هویت و داده در سرور MEELANO، نه داخل APK
- تنظیم آدرس سرویس از داخل خود برنامه
- پشتیبانی از HTTP برای شبکه داخلی و HTTPS برای محیط واقعی

## ساخت APK
1. Android Studio نصب و پروژه را باز کنید.
2. SDK Platform 35 و Build Tools متناظر را نصب کنید.
3. Gradle Sync.
4. `Build > Build APK(s)` برای Debug یا `Build > Generate Signed Bundle / APK` برای Release.

## آدرس سرویس
در اولین اجرا آدرس سایت/API MEELANO را وارد کنید، مانند:
- `https://meelano.example.com`
- `http://192.168.1.150:5000`

برای اینترنت عمومی از HTTPS استفاده کنید.
