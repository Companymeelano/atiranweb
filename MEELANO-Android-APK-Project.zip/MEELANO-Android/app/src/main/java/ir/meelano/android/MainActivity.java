package ir.meelano.android;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "meelano_android";
    private static final String KEY_URL = "web_url";
    private static final String DEFAULT_URL = "";

    private SharedPreferences prefs;
    private WebView webView;
    private TextView title;
    private TextView status;
    private boolean setupVisible = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(14, 17, 23));
        getWindow().setNavigationBarColor(Color.rgb(14, 17, 23));
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildShell();
        loadConfiguredUrl();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable background(int color, float radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(14, 17, 23));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), 0, dp(8), 0);
        bar.setBackgroundColor(Color.rgb(14, 17, 23));

        ImageView logo = new ImageView(this);
        logo.setImageResource(ir.meelano.android.R.drawable.meelano_3d);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(36), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(8), 0, 0, 0);
        title = new TextView(this);
        title.setText("MEELANO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        status = new TextView(this);
        status.setText("Atiran Management");
        status.setTextColor(Color.rgb(160, 165, 175));
        status.setTextSize(10);
        titles.addView(title);
        titles.addView(status);
        bar.addView(titles, new LinearLayout.LayoutParams(0, dp(42), 1f));

        ImageButton refresh = iconButton("↻");
        refresh.setOnClickListener(v -> {
            if (webView != null) webView.reload();
        });
        bar.addView(refresh, new LinearLayout.LayoutParams(dp(44), dp(42)));

        ImageButton settings = iconButton("⚙");
        settings.setOnClickListener(v -> showSettings());
        bar.addView(settings, new LinearLayout.LayoutParams(dp(44), dp(42)));

        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(50)));

        webView = new WebView(this);
        configureWebView();
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private ImageButton iconButton(String glyph) {
        ImageButton button = new ImageButton(this);
        button.setBackground(background(Color.TRANSPARENT, 12, Color.TRANSPARENT));
        button.setImageResource("↻".equals(glyph) ? android.R.drawable.ic_popup_sync : android.R.drawable.ic_menu_preferences);
        button.setColorFilter(Color.rgb(230, 196, 110));
        button.setPadding(dp(10), dp(10), dp(10), dp(10));
        button.setContentDescription(glyph);
        return button;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setBackgroundColor(Color.rgb(14, 17, 23));
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                status.setText("در حال اتصال…");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                status.setText("اتصال فعال");
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline("ارتباط با MEELANO برقرار نشد");
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {
                Toast.makeText(this, "امکان باز کردن خروجی وجود ندارد.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadConfiguredUrl() {
        String url = prefs.getString(KEY_URL, DEFAULT_URL).trim();
        if (url.isEmpty()) {
            showSetup();
        } else {
            loadUrl(url);
        }
    }

    private String normalizeUrl(String value) {
        String url = value.trim();
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        return url;
    }

    private void loadUrl(String url) {
        setupVisible = false;
        status.setText("در حال اتصال…");
        webView.setVisibility(View.VISIBLE);
        webView.loadUrl(normalizeUrl(url));
    }

    private void showSetup() {
        setupVisible = true;
        webView.setVisibility(View.GONE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(24), dp(24), dp(24), dp(24));
        panel.setBackground(background(Color.rgb(20, 24, 32), 26, Color.rgb(52, 58, 70)));

        ImageView logo = new ImageView(this);
        logo.setImageResource(ir.meelano.android.R.drawable.meelano_3d);
        logo.setAdjustViewBounds(true);
        panel.addView(logo, new LinearLayout.LayoutParams(dp(120), dp(120)));

        TextView h = new TextView(this);
        h.setText("MEELANO Android");
        h.setTextColor(Color.WHITE);
        h.setTextSize(23);
        h.setGravity(Gravity.CENTER);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        panel.addView(h, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView p = new TextView(this);
        p.setText("آدرس HTTPS سرویس MEELANO را وارد کنید. در شبکه داخلی می‌توانید آدرس API/وب داخلی را نیز وارد کنید.");
        p.setTextColor(Color.rgb(170, 175, 185));
        p.setTextSize(12);
        p.setGravity(Gravity.CENTER);
        panel.addView(p, new LinearLayout.LayoutParams(-1, dp(60)));

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(prefs.getString(KEY_URL, ""));
        input.setHint("https://meelano.example.com");
        input.setHintTextColor(Color.rgb(110, 115, 125));
        input.setTextColor(Color.WHITE);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(background(Color.rgb(27, 32, 41), 16, Color.rgb(65, 70, 82)));
        panel.addView(input, new LinearLayout.LayoutParams(-1, dp(52)));

        Button save = new Button(this);
        save.setText("اتصال و ورود به MEELANO");
        save.setTextColor(Color.WHITE);
        save.setAllCaps(false);
        save.setBackground(background(Color.rgb(185, 135, 55), 16, Color.TRANSPARENT));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(52));
        sp.topMargin = dp(14);
        panel.addView(save, sp);
        save.setOnClickListener(v -> {
            String url = normalizeUrl(input.getText().toString());
            if (url.length() < 8) {
                Toast.makeText(this, "آدرس سرویس معتبر نیست.", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString(KEY_URL, url).apply();
            loadUrl(url);
        });

        addContentView(panel, new ViewGroup.LayoutParams(-1, -1));
        panel.setTag("setup_panel");
    }

    private void showSettings() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(prefs.getString(KEY_URL, ""));
        input.setSelectAllOnFocus(true);
        input.setHint("https://meelano.example.com");
        input.setPadding(dp(14), 0, dp(14), 0);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("تنظیمات اتصال MEELANO")
                .setMessage("آدرس وب سرویس را تغییر دهید. برای استفاده امن در اینترنت از HTTPS استفاده کنید.")
                .setView(input)
                .setNegativeButton("انصراف", null)
                .setNeutralButton("پاک کردن", (d, w) -> {
                    prefs.edit().remove(KEY_URL).apply();
                    showSetup();
                })
                .setPositiveButton("ذخیره", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String url = input.getText().toString().trim();
            if (url.length() < 8) {
                input.setError("آدرس معتبر وارد کنید");
                return;
            }
            prefs.edit().putString(KEY_URL, normalizeUrl(url)).apply();
            dialog.dismiss();
            loadUrl(url);
        }));
        dialog.show();
    }

    private void showOffline(String message) {
        status.setText("اتصال برقرار نشد");
        Toast.makeText(this, message + " — تنظیمات اتصال را بررسی کنید.", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
