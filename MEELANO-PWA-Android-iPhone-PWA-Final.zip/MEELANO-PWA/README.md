# MEELANO PWA — Android / iPhone

نسخه موبایلی MEELANO به صورت **Progressive Web App (PWA)** ساخته شده است.

## امکانات موبایل

- نصب روی Android و iPhone بدون نیاز به فروشگاه
- RTL فارسی و امکان تغییر جهت RTL/LTR
- ۴ پوسته: Midnight / Champagne / Pearl / Default
- Sidebar واکنش‌گرا + Bottom Navigation موبایل
- کارت‌های KPI و نمودارهای لوکس
- 3D icon system بر پایه Assetهای MEELANO
- جدول‌های واکنش‌گرا: Desktop = Data Table، Mobile = Card Rows
- Customer 360 با Drawer
- Product Intelligence
- فروش، چک‌ها، ویزیتورها، ویزیت‌ها و اهداف
- گزارش‌های مدیریتی و Executive Analytics
- گزارش روزانه فروش و خرید
- Smart Search، Filter، CSV Export و Share
- تنظیم چگالی جدول و جهت نمایش
- نصب آفلاین پوسته/شل PWA و همگام‌سازی داده در زمان اتصال

## معماری اتصال

مرورگر موبایل **هرگز مستقیماً به SQL Server متصل نمی‌شود**. این موضوع برای امنیت و جلوگیری از قرار دادن SQL credential در JavaScript ضروری است.

جریان اتصال:

`Android/iPhone PWA → HTTPS API → SQL Server Atiran2`

API مسیر داخلی و سپس مسیر بیرونی را در سمت سرور بررسی می‌کند و بعد Atiran username/password را روی مخزن واقعی `visitors` / `sys_users` اعتبارسنجی می‌کند.

## اجرای API

پروژهٔ API در `server/` با .NET 8 ساخته شده است.

روی Windows/Linux دارای .NET 8 Runtime/SDK:

```bash
dotnet restore
dotnet publish -c Release -o publish
```

متغیرهای محیطی را فقط روی سرور تنظیم کنید:

```text
MEELANO_DB=Atiran2
MEELANO_SQL_INTERNAL_SERVER=192.168.1.150
MEELANO_SQL_EXTERNAL_SERVER=37.143.147.19
MEELANO_SQL_PORT=1433
MEELANO_SQL_INTERNAL_USER=...
MEELANO_SQL_INTERNAL_PASSWORD=...
MEELANO_SQL_EXTERNAL_USER=...
MEELANO_SQL_EXTERNAL_PASSWORD=...
```

**رمزهای واقعی در فایل PWA قرار داده نشده‌اند.**

## HTTPS

برای نصب PWA و استفاده روی iPhone/Android، نسخهٔ نهایی را با HTTPS منتشر کنید.

## نصب در گوشی

### Android
Chrome/Edge → منوی مرورگر → Install App / Add to Home Screen

### iPhone
Safari → Share → Add to Home Screen

## داده واقعی

هیچ داده نمونه یا Fake UI برای گزارش‌های عددی در نسخهٔ نهایی قرار نگرفته است. وقتی API داده واقعی برگرداند، همان داده در KPI، نمودار و جدول نمایش داده می‌شود. اگر یک گزارش به ستون‌های لازم دسترسی نداشته باشد، API آن گزارش را با دادهٔ ساختگی پر نمی‌کند.
