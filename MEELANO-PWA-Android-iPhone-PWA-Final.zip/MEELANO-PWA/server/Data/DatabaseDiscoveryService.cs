using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

public sealed class DatabaseDiscoveryService(AtiranConnectionFactory factory)
{
    /// <summary>
    /// Returns databases the current SQL login can actually use.
    /// The configured target database is checked first. If the login cannot enumerate
    /// master.sys.databases, the target database is still returned instead of making the
    /// application appear disconnected. This is important for restricted SQL logins.
    /// </summary>
    public async Task<IReadOnlyList<string>> ListDatabasesAsync(
        ConnectionProfile profile,
        string dbUser,
        string dbPassword,
        CancellationToken ct = default)
    {
        var target = profile.Database?.Trim();
        var result = new List<string>();

        if (!string.IsNullOrWhiteSpace(target))
        {
            await using var targetConnection = factory.Create(profile, dbUser, dbPassword);
            await targetConnection.OpenAsync(ct);
            await using var targetCommand = new SqlCommand("SELECT DB_NAME();", targetConnection);
            var currentDatabase = Convert.ToString(await targetCommand.ExecuteScalarAsync(ct));
            if (!string.IsNullOrWhiteSpace(currentDatabase))
                result.Add(currentDatabase);
        }

        // Enumeration is optional. Some SQL logins can use Atiran2 but are not allowed
        // to enumerate every database in master. In that case the target above is enough.
        try
        {
            var master = profile with { Database = "master" };
            await using var connection = factory.Create(master, dbUser, dbPassword);
            await connection.OpenAsync(ct);
            const string sql = @"
SELECT name
FROM sys.databases
WHERE state_desc = N'ONLINE'
  AND HAS_DBACCESS(name) = 1
ORDER BY name;";
            await using var command = new SqlCommand(sql, connection);
            await using var reader = await command.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                var name = reader.GetString(0);
                if (!result.Contains(name, StringComparer.OrdinalIgnoreCase))
                    result.Add(name);
            }
        }
        catch (SqlException)
        {
            // Do not discard a verified target database just because enumeration is restricted.
        }

        if (result.Count == 0 && !string.IsNullOrWhiteSpace(target))
            result.Add(target);

        return result
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => string.Equals(x, target, StringComparison.OrdinalIgnoreCase) ? 0 : 1)
            .ThenBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToArray();
    }
}
