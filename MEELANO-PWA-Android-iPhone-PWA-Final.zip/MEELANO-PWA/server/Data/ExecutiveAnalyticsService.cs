using System.Data;
using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

public sealed record AnalyticsPoint(string Label, decimal Value, decimal SecondaryValue = 0m);
public sealed record CheckStatusPoint(string Label, string Series, long Count, decimal Amount);
public sealed record BankPoint(string Label, decimal Balance, decimal Inflow, decimal Outflow);
public sealed record DailyDocumentRow(string Date, long DocumentNumber, string Customer, decimal Amount, long ItemCount, string? Description);
public sealed record DailyItemRow(string Item, decimal Quantity, decimal Amount);

public sealed record ExecutiveAnalyticsSnapshot(
    IReadOnlyList<AnalyticsPoint> WeeklySales,
    IReadOnlyList<AnalyticsPoint> MonthlyPurchaseSales,
    IReadOnlyList<CheckStatusPoint> CheckStatuses,
    IReadOnlyList<AnalyticsPoint> TopCustomers,
    IReadOnlyList<AnalyticsPoint> DebtAging,
    IReadOnlyList<AnalyticsPoint> MonthlyProfit,
    IReadOnlyList<BankPoint> Banks,
    IReadOnlyList<AnalyticsPoint> CategoryShare,
    IReadOnlyList<AnalyticsPoint> CustomerGrowth,
    IReadOnlyList<AnalyticsPoint> NetMargin,
    string? LatestSalesDate,
    string? LatestPurchaseDate,
    DateTime GeneratedAt);

public sealed record DailyReportSnapshot(
    string? SalesDate,
    decimal SalesTotal,
    decimal SalesDiscount,
    decimal SalesTax,
    decimal SalesReceived,
    long SalesDocuments,
    long SalesCustomers,
    long SalesItems,
    IReadOnlyList<DailyDocumentRow> SalesDocumentsRows,
    IReadOnlyList<DailyItemRow> SalesItemsRows,
    string? PurchaseDate,
    decimal PurchaseTotal,
    decimal PurchaseDiscount,
    decimal PurchaseTax,
    decimal PurchasePaid,
    long PurchaseDocuments,
    long PurchaseSuppliers,
    long PurchaseItems,
    IReadOnlyList<DailyDocumentRow> PurchaseDocumentsRows,
    IReadOnlyList<DailyItemRow> PurchaseItemsRows,
    DateTime GeneratedAt);

/// <summary>
/// Read-only executive analytics. Every report resolves columns at runtime and
/// returns an empty series when its real prerequisites are unavailable.
/// </summary>
public sealed class ExecutiveAnalyticsService(AtiranConnectionFactory factory)
{
    public async Task<ExecutiveAnalyticsSnapshot> LoadAsync(ConnectionProfile profile, string user, string password, int? visitorId, CancellationToken ct = default)
    {
        await using var c = factory.Create(profile, user, password);
        await c.OpenAsync(ct);

        var sailCols = await ColumnsAsync(c, "sailfact", ct);
        var subSaleCols = await ColumnsAsync(c, "subsailfact", ct);
        var buyCols = await ColumnsAsync(c, "buyfact", ct);
        var subBuyCols = await ColumnsAsync(c, "subbuyfact", ct);
        var customerCols = await ColumnsAsync(c, "CUSTOMERS", ct);
        var checkInCols = await ColumnsAsync(c, "getchk", ct);
        var checkOutCols = await ColumnsAsync(c, "putchk", ct);
        var bankCols = await ColumnsAsync(c, "BANK", ct);
        var inventoryCols = await ColumnsAsync(c, "inventory", ct);
        var groupCols = await ColumnsAsync(c, "kagroup", ct);
        var checkTypeCols = await ColumnsAsync(c, "CheckTypes", ct);

        var weeklySales = await LoadWeeklySalesAsync(c, sailCols, visitorId, ct);
        var monthlyPurchaseSales = await LoadMonthlyPurchaseSalesAsync(c, sailCols, buyCols, visitorId, ct);
        var statuses = await LoadCheckStatusesAsync(c, checkInCols, checkOutCols, checkTypeCols, customerCols, visitorId, ct);
        var topCustomers = await LoadTopCustomersAsync(c, sailCols, customerCols, visitorId, ct);
        var aging = await LoadDebtAgingAsync(c, sailCols, visitorId, ct);
        var monthlyProfit = await LoadMonthlyProfitAsync(c, sailCols, subSaleCols, inventoryCols, visitorId, ct);
        var banks = await LoadBanksAsync(c, bankCols, checkInCols, checkOutCols, ct);
        var categories = await LoadCategoryShareAsync(c, sailCols, subSaleCols, inventoryCols, groupCols, visitorId, ct);
        var customerGrowth = await LoadCustomerGrowthAsync(c, sailCols, visitorId, ct);
        var margin = await LoadNetMarginAsync(c, monthlyProfit, monthlyPurchaseSales);
        var latestSales = await LatestDateAsync(c, "sailfact", sailCols.Contains("date"), "date", ct);
        var latestPurchase = await LatestDateAsync(c, "buyfact", buyCols.Contains("DATE"), ResolveColumn(buyCols, "DATE"), ct);

        return new ExecutiveAnalyticsSnapshot(weeklySales, monthlyPurchaseSales, statuses, topCustomers,
            aging, monthlyProfit, banks, categories, customerGrowth, margin,
            latestSales, latestPurchase, DateTime.Now);
    }

    public async Task<DailyReportSnapshot> LoadDailyAsync(ConnectionProfile profile, string user, string password, int? visitorId,
        string? salesDate = null, string? purchaseDate = null, CancellationToken ct = default)
    {
        await using var c = factory.Create(profile, user, password);
        await c.OpenAsync(ct);

        var sailCols = await ColumnsAsync(c, "sailfact", ct);
        var subSaleCols = await ColumnsAsync(c, "subsailfact", ct);
        var buyCols = await ColumnsAsync(c, "buyfact", ct);
        var subBuyCols = await ColumnsAsync(c, "subbuyfact", ct);
        var inventoryCols = await ColumnsAsync(c, "inventory", ct);
        var customerCols = await ColumnsAsync(c, "CUSTOMERS", ct);

        var actualSalesDate = string.IsNullOrWhiteSpace(salesDate) ? await LatestDateAsync(c, "sailfact", sailCols.Contains("date"), "date", ct) : salesDate;
        var actualPurchaseDate = string.IsNullOrWhiteSpace(purchaseDate) ? await LatestDateAsync(c, "buyfact", buyCols.Contains("DATE"), ResolveColumn(buyCols, "DATE"), ct) : purchaseDate;

        var sales = await LoadDailySalesAsync(c, sailCols, subSaleCols, customerCols, visitorId, actualSalesDate, ct);
        var purchases = await LoadDailyPurchasesAsync(c, buyCols, subBuyCols, inventoryCols, customerCols, actualPurchaseDate, ct);
        var salesFinance = await LoadDailyFinanceAsync(c, "sailfact", sailCols, "date", actualSalesDate, visitorId, true, ct);
        var purchaseFinance = await LoadDailyFinanceAsync(c, "buyfact", buyCols, "DATE", actualPurchaseDate, null, false, ct);

        return new DailyReportSnapshot(actualSalesDate, sales.Total, salesFinance.Discount, salesFinance.Tax, salesFinance.Paid, sales.DocumentsCount, sales.CustomersCount,
            sales.ItemsCount, sales.Documents, sales.Items,
            actualPurchaseDate, purchases.Total, purchaseFinance.Discount, purchaseFinance.Tax, purchaseFinance.Paid, purchases.DocumentsCount, purchases.CustomersCount,
            purchases.ItemsCount, purchases.Documents, purchases.Items, DateTime.Now);
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadWeeklySalesAsync(SqlConnection c, HashSet<string> cols, int? visitorId, CancellationToken ct)
    {
        if (!cols.Contains("date") || !cols.Contains("all")) return Array.Empty<AnalyticsPoint>();
        var where = ActiveWhere("sailfact", cols);
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,[vis_rdf])=@vis");

        if (await HasFunctionAsync(c, "dif_date_alan", ct))
        {
            var sql = $@"WITH x AS (
    SELECT TRY_CONVERT(int, -dbo.dif_date_alan([date])) AS age_days,
           TRY_CONVERT(decimal(19,2),[all]) AS amount
    FROM dbo.sailfact {where}
), buckets AS (
    SELECT (age_days/7) AS week_index, SUM(amount) AS total
    FROM x
    WHERE age_days BETWEEN 0 AND 55
    GROUP BY (age_days/7)
)
SELECT TOP (8)
       CASE WHEN week_index=0 THEN N'هفته جاری' ELSE N'هفته ' + CONVERT(nvarchar(10),week_index+1) END AS label,
       ISNULL(total,0)
FROM buckets
ORDER BY week_index DESC;";
            var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
            rows.Reverse();
            return rows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
        }

        var fallback = $@"WITH x AS (
    SELECT [date], TRY_CONVERT(decimal(19,2),[all]) AS amount, TRY_CONVERT(int,SUBSTRING([date],9,2)) AS dayno
    FROM dbo.sailfact {where}
)
SELECT TOP (8) LEFT([date],7) + N' • هفته ' + CONVERT(nvarchar(10),((dayno-1)/7)+1) AS label, ISNULL(SUM(amount),0)
FROM x
WHERE dayno IS NOT NULL AND dayno BETWEEN 1 AND 31
GROUP BY LEFT([date],7), ((dayno-1)/7)+1
ORDER BY LEFT([date],7) DESC, ((dayno-1)/7)+1 DESC;";
        var fallbackRows = await ReadTwoColumnsAsync(c, fallback, visitorId, ct);
        fallbackRows.Reverse();
        return fallbackRows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadMonthlyPurchaseSalesAsync(SqlConnection c, HashSet<string> sailCols, HashSet<string> buyCols, int? visitorId, CancellationToken ct)
    {
        var sales = await LoadMonthlyMoneyAsync(c, "sailfact", sailCols, ResolveColumn(sailCols, "date"), "all", visitorId, ct);
        var purchases = await LoadMonthlyMoneyAsync(c, "buyfact", buyCols, ResolveColumn(buyCols, "DATE"), "all", null, ct);
        var labels = sales.Select(x => x.Label).Concat(purchases.Select(x => x.Label)).Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.Ordinal).TakeLast(12).ToArray();
        var salesMap = sales.ToDictionary(x => x.Label, x => x.Value, StringComparer.OrdinalIgnoreCase);
        var buyMap = purchases.ToDictionary(x => x.Label, x => x.Value, StringComparer.OrdinalIgnoreCase);
        return labels.Select(label => new AnalyticsPoint(label, salesMap.TryGetValue(label, out var s) ? s : 0m, buyMap.TryGetValue(label, out var p) ? p : 0m)).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadMonthlyMoneyAsync(SqlConnection c, string table, HashSet<string> cols, string dateColumn, string amountColumn, int? visitorId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(dateColumn) || !cols.Contains(amountColumn)) return Array.Empty<AnalyticsPoint>();
        var where = ActiveWhere(table, cols);
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,[vis_rdf])=@vis");
        var sql = $@"SELECT TOP (12) LEFT([{dateColumn}],7), ISNULL(SUM(TRY_CONVERT(decimal(19,2),[{amountColumn}])),0)
FROM dbo.[{table}] {where}
GROUP BY LEFT([{dateColumn}],7)
ORDER BY LEFT([{dateColumn}],7) DESC;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        rows.Reverse();
        return rows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
    }

    async Task<IReadOnlyList<CheckStatusPoint>> LoadCheckStatusesAsync(SqlConnection c, HashSet<string> getCols, HashSet<string> putCols, HashSet<string> typeCols, HashSet<string> customerCols, int? visitorId, CancellationToken ct)
    {
        var result = new List<CheckStatusPoint>();
        if (getCols.Contains("chk_satus") && getCols.Contains("getchkmab"))
        {
            var typeJoin = typeCols.Contains("ID") && typeCols.Contains("Desciption")
                ? " LEFT JOIN dbo.CheckTypes t ON t.ID=g.chk_satus " : "";
            var label = typeCols.Contains("ID") && typeCols.Contains("Desciption")
                ? "N'دریافتی • ' + COALESCE(TRY_CONVERT(nvarchar(100),t.Desciption),N'وضعیت '+CONVERT(nvarchar(20),g.chk_satus))"
                : "N'دریافتی • وضعیت ' + CONVERT(nvarchar(20),g.chk_satus)";
            var where = "";
            if (visitorId.HasValue && getCols.Contains("vis_rdf")) where = " WHERE TRY_CONVERT(int,g.vis_rdf)=@vis";
            else if (visitorId.HasValue && getCols.Contains("shmo") && customerCols.Contains("SHMO") && customerCols.Contains("vis_rdf"))
                where = " WHERE EXISTS (SELECT 1 FROM dbo.CUSTOMERS c WHERE c.SHMO=g.shmo AND TRY_CONVERT(int,c.vis_rdf)=@vis)";
            var sql = $@"SELECT {label}, COUNT_BIG(1), ISNULL(SUM(TRY_CONVERT(decimal(19,2),g.[getchkmab])),0)
FROM dbo.getchk g {typeJoin} {where}
GROUP BY {label};";
            result.AddRange(await ReadCheckRowsAsync(c, sql, visitorId, ct));
        }
        if (putCols.Contains("putchk_status") && putCols.Contains("putchkmab"))
        {
            var typeJoin = typeCols.Contains("ID") && typeCols.Contains("Desciption")
                ? " LEFT JOIN dbo.CheckTypes t ON t.ID=p.putchk_status " : "";
            var label = typeCols.Contains("ID") && typeCols.Contains("Desciption")
                ? "N'پرداختی • ' + COALESCE(TRY_CONVERT(nvarchar(100),t.Desciption),N'وضعیت '+CONVERT(nvarchar(20),p.putchk_status))"
                : "N'پرداختی • وضعیت ' + CONVERT(nvarchar(20),p.putchk_status)";
            var where = "";
            if (visitorId.HasValue && putCols.Contains("shmo") && customerCols.Contains("SHMO") && customerCols.Contains("vis_rdf"))
                where = " WHERE EXISTS (SELECT 1 FROM dbo.CUSTOMERS c WHERE c.SHMO=p.shmo AND TRY_CONVERT(int,c.vis_rdf)=@vis)";
            var sql = $@"SELECT {label}, COUNT_BIG(1), ISNULL(SUM(TRY_CONVERT(decimal(19,2),p.[putchkmab])),0)
FROM dbo.putchk p {typeJoin} {where}
GROUP BY {label};";
            result.AddRange(await ReadCheckRowsAsync(c, sql, visitorId, ct));
        }
        return result.OrderByDescending(x => x.Amount).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadTopCustomersAsync(SqlConnection c, HashSet<string> sailCols, HashSet<string> customerCols, int? visitorId, CancellationToken ct)
    {
        if (!sailCols.Contains("shmo") || !sailCols.Contains("all") || !customerCols.Contains("SHMO")) return Array.Empty<AnalyticsPoint>();
        var name = customerCols.Contains("MONAME") ? "TRY_CONVERT(nvarchar(250),c.MONAME)" : "N'بدون نام'";
        var where = ActiveWhere("sailfact", sailCols, "s");
        if (visitorId.HasValue && sailCols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,s.vis_rdf)=@vis");
        var sql = $@"SELECT TOP (10) {name}, ISNULL(SUM(TRY_CONVERT(decimal(19,2),s.[all])),0)
FROM dbo.CUSTOMERS c JOIN dbo.sailfact s ON s.shmo=c.SHMO
{where}
GROUP BY c.SHMO,{name}
ORDER BY ISNULL(SUM(TRY_CONVERT(decimal(19,2),s.[all])),0) DESC;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        return rows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadDebtAgingAsync(SqlConnection c, HashSet<string> cols, int? visitorId, CancellationToken ct)
    {
        if (!cols.Contains("t_date") || !cols.Contains("all") || !cols.Contains("tasvieh")) return Array.Empty<AnalyticsPoint>();
        if (!await HasFunctionAsync(c, "dif_date_alan", ct)) return Array.Empty<AnalyticsPoint>();
        var baseAmount = cols.Contains("all_fel") ? "TRY_CONVERT(decimal(19,2),[all_fel])" : "TRY_CONVERT(decimal(19,2),[all])";
        var deductions = new List<string>();
        if (cols.Contains("MabDaryaftFactor")) deductions.Add("ISNULL(TRY_CONVERT(decimal(19,2),[MabDaryaftFactor]),0)");
        if (cols.Contains("tdf")) deductions.Add("ISNULL(TRY_CONVERT(decimal(19,2),[tdf]),0)");
        var remainExpr = deductions.Count == 0 ? baseAmount : $"({baseAmount} - {string.Join(" - ", deductions)})";
        var where = "WHERE [active]='t' AND [tasvieh]='f' AND NULLIF([t_date],'') IS NOT NULL";
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,[vis_rdf])=@vis");
        var sql = $@"WITH x AS (
SELECT CASE
 WHEN dbo.dif_date_alan([t_date]) >= 0 THEN N'جاری / بدون تأخیر'
 WHEN -dbo.dif_date_alan([t_date]) <= 30 THEN N'۱ تا ۳۰ روز'
 WHEN -dbo.dif_date_alan([t_date]) <= 60 THEN N'۳۱ تا ۶۰ روز'
 WHEN -dbo.dif_date_alan([t_date]) <= 90 THEN N'۶۱ تا ۹۰ روز'
 WHEN -dbo.dif_date_alan([t_date]) <= 180 THEN N'۹۱ تا ۱۸۰ روز'
 ELSE N'بیش از ۱۸۰ روز' END bucket,
{remainExpr} amount
FROM dbo.sailfact {where})
SELECT bucket, SUM(CASE WHEN amount>0 THEN amount ELSE 0 END) FROM x GROUP BY bucket;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        return rows.Select(x => new AnalyticsPoint(x.Label, x.Value / 1000000m)).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadMonthlyProfitAsync(SqlConnection c, HashSet<string> sailCols, HashSet<string> detailCols, HashSet<string> inventoryCols, int? visitorId, CancellationToken ct)
    {
        if (!sailCols.Contains("date") || !sailCols.Contains("shfacfo") || !detailCols.Contains("shfacfo") || !detailCols.Contains("SHKA") || !detailCols.Contains("LINESUM") || !inventoryCols.Contains("shka") || !inventoryCols.Contains("pure_buy_price") || !inventoryCols.Contains("mohvah")) return Array.Empty<AnalyticsPoint>();
        var qty = "(ISNULL(TRY_CONVERT(decimal(19,4),d.TEDVAH),0)*NULLIF(TRY_CONVERT(decimal(19,4),i.mohvah),0)+ISNULL(TRY_CONVERT(decimal(19,4),d.TEDJOZ),0))";
        var where = ActiveWhere("sailfact", sailCols, "s");
        if (detailCols.Contains("active")) where = AppendCondition(where, "d.active='t'");
        if (visitorId.HasValue && sailCols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,s.vis_rdf)=@vis");
        var sql = $@"SELECT TOP (12) LEFT(s.[date],7),
ISNULL(SUM(TRY_CONVERT(decimal(19,2),d.[LINESUM]) - ({qty} * ISNULL(TRY_CONVERT(decimal(19,2),i.[pure_buy_price]),0))),0)
FROM dbo.sailfact s
JOIN dbo.subsailfact d ON d.shfacfo=s.shfacfo
JOIN dbo.inventory i ON i.shka=d.SHKA
{where}
GROUP BY LEFT(s.[date],7)
ORDER BY LEFT(s.[date],7) DESC;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        rows.Reverse();
        return rows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
    }

    async Task<IReadOnlyList<BankPoint>> LoadBanksAsync(SqlConnection c, HashSet<string> bankCols, HashSet<string> getCols, HashSet<string> putCols, CancellationToken ct)
    {
        if (!bankCols.Contains("RDF") || !bankCols.Contains("BANKNAME") || !bankCols.Contains("MAN")) return Array.Empty<BankPoint>();
        var inflow = getCols.Contains("our_bankrdf") && getCols.Contains("getchkmab")
            ? "ISNULL((SELECT SUM(TRY_CONVERT(decimal(19,2),g.getchkmab)) FROM dbo.getchk g WHERE g.our_bankrdf=b.RDF),0)" : "CAST(0 AS decimal(19,2))";
        var outflow = putCols.Contains("bankrdf") && putCols.Contains("putchkmab")
            ? "ISNULL((SELECT SUM(TRY_CONVERT(decimal(19,2),p.putchkmab)) FROM dbo.putchk p WHERE p.bankrdf=b.RDF),0)" : "CAST(0 AS decimal(19,2))";
        var active = bankCols.Contains("Active") ? " WHERE ISNULL(b.Active,1)=1" : "";
        var sql = $@"SELECT TOP (20) TRY_CONVERT(nvarchar(250),b.BANKNAME),
ISNULL(TRY_CONVERT(decimal(19,2),b.MAN),0), {inflow}, {outflow}
FROM dbo.BANK b {active}
ORDER BY ISNULL(TRY_CONVERT(decimal(19,2),b.MAN),0) DESC;";
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<BankPoint>();
        while (await r.ReadAsync(ct)) list.Add(new BankPoint(r.IsDBNull(0) ? "بدون نام" : Convert.ToString(r.GetValue(0)) ?? "بدون نام", r.IsDBNull(1) ? 0m : Convert.ToDecimal(r.GetValue(1)), r.IsDBNull(2) ? 0m : Convert.ToDecimal(r.GetValue(2)), r.IsDBNull(3) ? 0m : Convert.ToDecimal(r.GetValue(3))));
        return list;
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadCategoryShareAsync(SqlConnection c, HashSet<string> sailCols, HashSet<string> detailCols, HashSet<string> inventoryCols, HashSet<string> groupCols, int? visitorId, CancellationToken ct)
    {
        if (!sailCols.Contains("shfacfo") || !sailCols.Contains("active") || !detailCols.Contains("shfacfo") || !detailCols.Contains("SHKA") || !detailCols.Contains("LINESUM") || !inventoryCols.Contains("shka") || !inventoryCols.Contains("group_rdf") || !groupCols.Contains("group_rdf") || !groupCols.Contains("group_name")) return Array.Empty<AnalyticsPoint>();
        var where = "WHERE s.active='t'";
        if (detailCols.Contains("active")) where = AppendCondition(where, "d.active='t'");
        if (visitorId.HasValue && sailCols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,s.vis_rdf)=@vis");
        var sql = $@"SELECT TOP (8) TRY_CONVERT(nvarchar(250),g.group_name), ISNULL(SUM(TRY_CONVERT(decimal(19,2),d.LINESUM)),0)
FROM dbo.sailfact s
JOIN dbo.subsailfact d ON d.shfacfo=s.shfacfo
JOIN dbo.inventory i ON i.shka=d.SHKA
LEFT JOIN dbo.kagroup g ON g.group_rdf=i.group_rdf
{where}
GROUP BY g.group_name
ORDER BY ISNULL(SUM(TRY_CONVERT(decimal(19,2),d.LINESUM)),0) DESC;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        return rows.Select(x => new AnalyticsPoint(string.IsNullOrWhiteSpace(x.Label) ? "بدون گروه" : x.Label, x.Value)).ToArray();
    }

    async Task<IReadOnlyList<AnalyticsPoint>> LoadCustomerGrowthAsync(SqlConnection c, HashSet<string> cols, int? visitorId, CancellationToken ct)
    {
        if (!cols.Contains("date") || !cols.Contains("shmo")) return Array.Empty<AnalyticsPoint>();
        var where = ActiveWhere("sailfact", cols);
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,[vis_rdf])=@vis");
        var sql = $@"SELECT TOP (12) LEFT([date],7), COUNT(DISTINCT [shmo])
FROM dbo.sailfact {where}
GROUP BY LEFT([date],7)
ORDER BY LEFT([date],7) DESC;";
        var rows = await ReadTwoColumnsAsync(c, sql, visitorId, ct);
        rows.Reverse();
        return rows.Select(x => new AnalyticsPoint(x.Label, x.Value)).ToArray();
    }

    Task<IReadOnlyList<AnalyticsPoint>> LoadNetMarginAsync(SqlConnection c, IReadOnlyList<AnalyticsPoint> profit, IReadOnlyList<AnalyticsPoint> purchaseSales, CancellationToken ct = default)
    {
        var sales = purchaseSales.ToDictionary(x => x.Label, x => x.Value, StringComparer.OrdinalIgnoreCase);
        var result = profit.Select(x => new AnalyticsPoint(x.Label, sales.TryGetValue(x.Label, out var s) && s != 0 ? (x.Value / s) * 100m : 0m)).ToArray();
        return Task.FromResult<IReadOnlyList<AnalyticsPoint>>(result);
    }


    async Task<(decimal Discount, decimal Tax, decimal Paid)> LoadDailyFinanceAsync(SqlConnection c, string table, HashSet<string> cols, string dateColumn, string? date, int? visitorId, bool sales, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(date) || !cols.Contains(dateColumn)) return (0m, 0m, 0m);
        var discountColumn = cols.Contains("tafif") ? "tafif" : "";
        var taxColumn = cols.Contains("tax") ? "tax" : "";
        var paidColumn = sales ? (cols.Contains("MabDaryaftFactor") ? "MabDaryaftFactor" : "") : (cols.Contains("MablaghPardakht") ? "MablaghPardakht" : "");
        var selectDiscount = string.IsNullOrWhiteSpace(discountColumn) ? "CAST(0 AS decimal(19,2))" : $"ISNULL(SUM(TRY_CONVERT(decimal(19,2),[{discountColumn}])),0)";
        var selectTax = string.IsNullOrWhiteSpace(taxColumn) ? "CAST(0 AS decimal(19,2))" : $"ISNULL(SUM(TRY_CONVERT(decimal(19,2),[{taxColumn}])),0)";
        var selectPaid = string.IsNullOrWhiteSpace(paidColumn) ? "CAST(0 AS decimal(19,2))" : $"ISNULL(SUM(TRY_CONVERT(decimal(19,2),[{paidColumn}])),0)";
        var where = $"WHERE [{dateColumn}]=@date";
        if (cols.Contains("active")) where = AppendCondition(where, $"[{(table.Equals("sailfact", StringComparison.OrdinalIgnoreCase) ? "active" : "active")}]='t'");
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,[vis_rdf])=@vis");
        var sql = $"SELECT {selectDiscount},{selectTax},{selectPaid} FROM dbo.[{table}] {where};";
        await using var cmd = new SqlCommand(sql, c); cmd.Parameters.Add("@date", SqlDbType.NVarChar, 20).Value = date;
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        if (!await r.ReadAsync(ct)) return (0m,0m,0m);
        return (r.IsDBNull(0) ? 0m : Convert.ToDecimal(r.GetValue(0)), r.IsDBNull(1) ? 0m : Convert.ToDecimal(r.GetValue(1)), r.IsDBNull(2) ? 0m : Convert.ToDecimal(r.GetValue(2)));
    }

    async Task<(decimal Total, long DocumentsCount, long CustomersCount, long ItemsCount, IReadOnlyList<DailyDocumentRow> Documents, IReadOnlyList<DailyItemRow> Items)> LoadDailySalesAsync(SqlConnection c, HashSet<string> sailCols, HashSet<string> detailCols, HashSet<string> customerCols, int? visitorId, string? date, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(date) || !sailCols.Contains("date") || !sailCols.Contains("all") || !sailCols.Contains("shfacfo"))
            return (0m,0,0,0,Array.Empty<DailyDocumentRow>(),Array.Empty<DailyItemRow>());
        var where = "WHERE s.[date]=@date";
        if (sailCols.Contains("active")) where = AppendCondition(where, "s.active='t'");
        if (visitorId.HasValue && sailCols.Contains("vis_rdf")) where = AppendCondition(where, "TRY_CONVERT(int,s.vis_rdf)=@vis");
        var customerName = customerCols.Contains("MONAME") ? "COALESCE(TRY_CONVERT(nvarchar(250),c.MONAME),TRY_CONVERT(nvarchar(250),s.moname),N'بدون نام')" : "COALESCE(TRY_CONVERT(nvarchar(250),s.moname),N'بدون نام')";
        var itemCount = detailCols.Contains("shfacfo") ? "ISNULL(ic.item_count,0)" : "CAST(0 AS bigint)";
        var desc = sailCols.Contains("description") ? "TRY_CONVERT(nvarchar(500),s.description)" : "CAST(NULL AS nvarchar(500))";
        var sql = $@"SELECT s.[date], TRY_CONVERT(bigint,s.shfacfo), {customerName}, TRY_CONVERT(decimal(19,2),s.[all]), {itemCount}, {desc}
FROM dbo.sailfact s
{(customerCols.Contains("SHMO") ? "LEFT JOIN dbo.CUSTOMERS c ON c.SHMO=s.shmo" : "")}
{(detailCols.Contains("shfacfo") ? "OUTER APPLY (SELECT COUNT_BIG(1) item_count FROM dbo.subsailfact d WHERE d.shfacfo=s.shfacfo" + (detailCols.Contains("active") ? " AND d.active='t'" : "") + ") ic" : "")}
{where}
ORDER BY s.shfacfo;";
        var docs = await ReadDailyDocsAsync(c, sql, date, visitorId, ct);
        var itemsSql = detailCols.Contains("SHKA") && detailCols.Contains("LINESUM")
            ? $@"SELECT COALESCE(NULLIF(TRY_CONVERT(nvarchar(500),d.naka),N''),TRY_CONVERT(nvarchar(500),i.naka),N'بدون نام'),
ISNULL(SUM(ISNULL(TRY_CONVERT(decimal(19,4),d.TEDVAH),0)*ISNULL(TRY_CONVERT(decimal(19,4),i.mohvah),1)+ISNULL(TRY_CONVERT(decimal(19,4),d.TEDJOZ),0)),0),
ISNULL(SUM(TRY_CONVERT(decimal(19,2),d.LINESUM)),0)
FROM dbo.subsailfact d JOIN dbo.sailfact s ON s.shfacfo=d.shfacfo
LEFT JOIN dbo.inventory i ON i.shka=d.SHKA
WHERE s.[date]=@date" + (sailCols.Contains("active") ? " AND s.active='t'" : "") + (detailCols.Contains("active") ? " AND d.active='t'" : "") + (visitorId.HasValue && sailCols.Contains("vis_rdf") ? " AND TRY_CONVERT(int,s.vis_rdf)=@vis" : "") + " GROUP BY COALESCE(NULLIF(TRY_CONVERT(nvarchar(500),d.naka),N''),TRY_CONVERT(nvarchar(500),i.naka),N'بدون نام') ORDER BY 3 DESC;"
            : "";
        var items = string.IsNullOrWhiteSpace(itemsSql) ? Array.Empty<DailyItemRow>() : await ReadDailyItemsAsync(c, itemsSql, date, visitorId, ct);
        var total = docs.Sum(x => x.Amount);
        var docsCount = docs.Count;
        var customers = docs.Select(x => x.Customer).Distinct(StringComparer.OrdinalIgnoreCase).LongCount();
        var itemCountTotal = items.Sum(x => (long)Math.Max(0m, x.Quantity));
        return (total, docsCount, customers, itemCountTotal, docs, items);
    }

    async Task<(decimal Total, long DocumentsCount, long CustomersCount, long ItemsCount, IReadOnlyList<DailyDocumentRow> Documents, IReadOnlyList<DailyItemRow> Items)> LoadDailyPurchasesAsync(SqlConnection c, HashSet<string> buyCols, HashSet<string> detailCols, HashSet<string> inventoryCols, HashSet<string> customerCols, string? date, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(date) || !buyCols.Contains("DATE") || !buyCols.Contains("all") || !buyCols.Contains("shfackh"))
            return (0m,0,0,0,Array.Empty<DailyDocumentRow>(),Array.Empty<DailyItemRow>());
        var where = "WHERE b.[DATE]=@date";
        if (buyCols.Contains("active")) where = AppendCondition(where, "b.active='t'");
        var name = customerCols.Contains("MONAME") ? "COALESCE(TRY_CONVERT(nvarchar(250),c.MONAME),N'بدون نام')" : "N'بدون نام'";
        var itemCount = detailCols.Contains("shfackh") ? "ISNULL(ic.item_count,0)" : "CAST(0 AS bigint)";
        var desc = buyCols.Contains("Explain") ? "TRY_CONVERT(nvarchar(500),b.Explain)" : "CAST(NULL AS nvarchar(500))";
        var sql = $@"SELECT b.[DATE], TRY_CONVERT(bigint,b.shfackh), {name}, TRY_CONVERT(decimal(19,2),b.[all]), {itemCount}, {desc}
FROM dbo.buyfact b
{(customerCols.Contains("SHMO") ? "LEFT JOIN dbo.CUSTOMERS c ON c.SHMO=b.shmo" : "")}
{(detailCols.Contains("shfackh") ? "OUTER APPLY (SELECT COUNT_BIG(1) item_count FROM dbo.subbuyfact d WHERE d.shfackh=b.shfackh" + (detailCols.Contains("active") ? " AND d.active='t'" : "") + ") ic" : "")}
{where}
ORDER BY b.shfackh;";
        var docs = await ReadDailyDocsAsync(c, sql, date, null, ct);
        var itemsSql = detailCols.Contains("shka") && detailCols.Contains("tamam_joz")
            ? $@"SELECT COALESCE(NULLIF(TRY_CONVERT(nvarchar(500),d.Desc_Naka),N''),TRY_CONVERT(nvarchar(500),i.naka),N'بدون نام'),
ISNULL(SUM(ISNULL(TRY_CONVERT(decimal(19,4),d.TEDVAH),0)*ISNULL(TRY_CONVERT(decimal(19,4),i.mohvah),1)+ISNULL(TRY_CONVERT(decimal(19,4),d.TEDJOZ),0)),0),
ISNULL(SUM(TRY_CONVERT(decimal(19,2),d.tamam_joz)),0)
FROM dbo.subbuyfact d JOIN dbo.buyfact b ON b.shfackh=d.shfackh
LEFT JOIN dbo.inventory i ON i.shka=d.shka
WHERE b.[DATE]=@date" + (buyCols.Contains("active") ? " AND b.active='t'" : "") + (detailCols.Contains("active") ? " AND d.active='t'" : "") + " GROUP BY COALESCE(NULLIF(TRY_CONVERT(nvarchar(500),d.Desc_Naka),N''),TRY_CONVERT(nvarchar(500),i.naka),N'بدون نام') ORDER BY 3 DESC;"
            : "";
        var items = string.IsNullOrWhiteSpace(itemsSql) ? Array.Empty<DailyItemRow>() : await ReadDailyItemsAsync(c, itemsSql, date, null, ct);
        var total = docs.Sum(x => x.Amount);
        var docsCount = docs.Count;
        var customers = docs.Select(x => x.Customer).Distinct(StringComparer.OrdinalIgnoreCase).LongCount();
        var itemCountTotal = items.Sum(x => (long)Math.Max(0m, x.Quantity));
        return (total, docsCount, customers, itemCountTotal, docs, items);
    }

    static async Task<IReadOnlyList<DailyDocumentRow>> ReadDailyDocsAsync(SqlConnection c, string sql, string date, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        cmd.Parameters.Add("@date", SqlDbType.NVarChar, 20).Value = date;
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<DailyDocumentRow>();
        while (await r.ReadAsync(ct)) list.Add(new DailyDocumentRow(
            r.IsDBNull(0) ? date : Convert.ToString(r.GetValue(0)) ?? date,
            r.IsDBNull(1) ? 0L : Convert.ToInt64(r.GetValue(1)),
            r.IsDBNull(2) ? "بدون نام" : Convert.ToString(r.GetValue(2)) ?? "بدون نام",
            r.IsDBNull(3) ? 0m : Convert.ToDecimal(r.GetValue(3)),
            r.IsDBNull(4) ? 0L : Convert.ToInt64(r.GetValue(4)),
            r.IsDBNull(5) ? null : Convert.ToString(r.GetValue(5))));
        return list;
    }

    static async Task<IReadOnlyList<DailyItemRow>> ReadDailyItemsAsync(SqlConnection c, string sql, string date, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        cmd.Parameters.Add("@date", SqlDbType.NVarChar, 20).Value = date;
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<DailyItemRow>();
        while (await r.ReadAsync(ct)) list.Add(new DailyItemRow(
            r.IsDBNull(0) ? "بدون نام" : Convert.ToString(r.GetValue(0)) ?? "بدون نام",
            r.IsDBNull(1) ? 0m : Convert.ToDecimal(r.GetValue(1)),
            r.IsDBNull(2) ? 0m : Convert.ToDecimal(r.GetValue(2))));
        return list;
    }

    static async Task<IReadOnlyList<(string Label, decimal Value)>> ReadTwoColumnsAsync(SqlConnection c, string sql, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<(string Label, decimal Value)>();
        while (await r.ReadAsync(ct)) list.Add((r.IsDBNull(0) ? "—" : Convert.ToString(r.GetValue(0)) ?? "—", r.IsDBNull(1) ? 0m : Convert.ToDecimal(r.GetValue(1))));
        return list;
    }

    static async Task<IReadOnlyList<CheckStatusPoint>> ReadCheckRowsAsync(SqlConnection c, string sql, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<CheckStatusPoint>();
        while (await r.ReadAsync(ct)) list.Add(new CheckStatusPoint(r.IsDBNull(0) ? "وضعیت نامشخص" : Convert.ToString(r.GetValue(0)) ?? "وضعیت نامشخص", "چک", r.IsDBNull(1) ? 0L : Convert.ToInt64(r.GetValue(1)), r.IsDBNull(2) ? 0m : Convert.ToDecimal(r.GetValue(2))));
        return list;
    }

    static async Task<string?> LatestDateAsync(SqlConnection c, string table, bool available, string? column, CancellationToken ct)
    {
        if (!available || string.IsNullOrWhiteSpace(column)) return null;
        var sql = $"SELECT MAX(NULLIF(CONVERT(nvarchar(20),[{column}]),N'')) FROM dbo.[{table}];";
        await using var cmd = new SqlCommand(sql, c);
        var v = await cmd.ExecuteScalarAsync(ct);
        return v is null or DBNull ? null : Convert.ToString(v);
    }

    static async Task<bool> HasFunctionAsync(SqlConnection c, string name, CancellationToken ct)
    {
        const string sql = "SELECT COUNT_BIG(1) FROM sys.objects WHERE type IN ('FN','IF','TF') AND name=@n;";
        await using var cmd = new SqlCommand(sql, c); cmd.Parameters.Add("@n", SqlDbType.NVarChar, 128).Value = name;
        return Convert.ToInt64(await cmd.ExecuteScalarAsync(ct) ?? 0L) > 0;
    }


    static string AppendCondition(string where, string condition)
        => string.IsNullOrWhiteSpace(where) ? $"WHERE {condition}" : $"{where} AND {condition}";

    static string ActiveWhere(string table, HashSet<string> cols, string? alias = null)
    {
        var p = string.IsNullOrWhiteSpace(alias) ? "" : alias + ".";
        return cols.Contains("active") ? $"WHERE {p}[active]='t'" : "";
    }

    static string ResolveColumn(HashSet<string> cols, params string[] candidates)
        => candidates.FirstOrDefault(x => cols.Contains(x)) ?? "";

    static async Task<HashSet<string>> ColumnsAsync(SqlConnection c, string table, CancellationToken ct)
    {
        const string sql = "SELECT c.name FROM sys.columns c JOIN sys.tables t ON t.object_id=c.object_id JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE s.name=N'dbo' AND t.name=@t ORDER BY c.column_id";
        await using var cmd = new SqlCommand(sql, c); cmd.Parameters.Add("@t", SqlDbType.NVarChar, 128).Value = table;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<string>();
        while (await r.ReadAsync(ct)) list.Add(r.GetString(0));
        return new HashSet<string>(list, StringComparer.OrdinalIgnoreCase);
    }
}
