using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

public sealed record DashboardMetric(string Title, string Table, long Value, bool Available, string? Error = null);

public sealed class DashboardStatsService(AtiranConnectionFactory factory)
{
    private static readonly (string Title, string Table)[] Targets =
    {
        ("مشتریان", "CUSTOMERS"),
        ("کالاها", "inventory"),
        ("فروش", "sailfact"),
        ("پیش‌فاکتور", "sailfact_pish"),
        ("چک دریافتی", "getchk"),
        ("چک پرداختی", "putchk"),
        ("ویزیتورها", "visitors"),
        ("اهداف", "vis_goals")
    };

    public async Task<IReadOnlyList<DashboardMetric>> LoadAsync(ConnectionProfile profile, string user, string password, int? visitorId, CancellationToken ct = default)
    {
        await using var connection = factory.Create(profile, user, password);
        await connection.OpenAsync(ct);
        var result = new List<DashboardMetric>(Targets.Length);

        foreach (var target in Targets)
        {
            try
            {
                var sql = $"SELECT COUNT_BIG(1) FROM dbo.[{target.Table}]";
                if (visitorId.HasValue && (target.Table.Equals("CUSTOMERS", StringComparison.OrdinalIgnoreCase) ||
                                           target.Table.Equals("sailfact", StringComparison.OrdinalIgnoreCase) ||
                                           target.Table.Equals("vis_goals", StringComparison.OrdinalIgnoreCase)))
                {
                    var column = target.Table.Equals("CUSTOMERS", StringComparison.OrdinalIgnoreCase) ? "vis_rdf" : "vis_rdf";
                    sql += $" WHERE [{column}]=@visitorId";
                }

                await using var command = new SqlCommand(sql, connection);
                if (sql.Contains("@visitorId", StringComparison.Ordinal) && visitorId.HasValue)
                    command.Parameters.AddWithValue("@visitorId", visitorId.GetValueOrDefault());
                var scalar = await command.ExecuteScalarAsync(ct);
                var count = scalar is null || scalar is DBNull ? 0L : Convert.ToInt64(scalar);
                result.Add(new(target.Title, target.Table, count, true));
            }
            catch (Exception ex)
            {
                result.Add(new(target.Title, target.Table, 0, false, ex.Message));
            }
        }
        return result;
    }
}
