using Microsoft.Data.SqlClient; using Atiran.Management.Domain; using Atiran.Management.Infrastructure;
namespace Atiran.Management.Data;
public sealed class SchemaDiscoveryService(AtiranConnectionFactory factory)
{
 public async Task<IReadOnlyList<SchemaTable>> DiscoverAsync(ConnectionProfile p,string user,string password,CancellationToken ct=default)
 {
  await using var c=factory.Create(p,user,password); await c.OpenAsync(ct);
  const string sql=@"SELECT s.name,t.name,COUNT(DISTINCT c.column_id),CONVERT(bit,CASE WHEN EXISTS(SELECT 1 FROM sys.indexes i WHERE i.object_id=t.object_id AND i.is_primary_key=1) THEN 1 ELSE 0 END),CONVERT(bit,CASE WHEN EXISTS(SELECT 1 FROM sys.foreign_keys f WHERE f.parent_object_id=t.object_id OR f.referenced_object_id=t.object_id) THEN 1 ELSE 0 END) FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id JOIN sys.columns c ON c.object_id=t.object_id GROUP BY s.name,t.name,t.object_id ORDER BY s.name,t.name";
  var list=new List<SchemaTable>(); await using var cmd=new SqlCommand(sql,c); await using var r=await cmd.ExecuteReaderAsync(ct); while(await r.ReadAsync(ct)) list.Add(new(r.GetString(0),r.GetString(1),r.GetInt32(2),r.GetBoolean(3),r.GetBoolean(4))); return list;
 }
}
