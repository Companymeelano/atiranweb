using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

/// <summary>
/// Read-only Atiran repository. Queries are built only from columns that are
/// verified against the live SQL Server schema, so a missing optional column
/// cannot make the whole Customers/Products screen empty.
/// </summary>
public sealed class AtiranRepository(AtiranConnectionFactory factory)
{
    public async Task<IReadOnlyList<CustomerRow>> CustomersAsync(
        ConnectionProfile p, string user, string password, int? visitorId, string? search,
        CancellationToken ct = default)
    {
        await using var c = factory.Create(p, user, password);
        await c.OpenAsync(ct);
        var cols = await ColumnsAsync(c, "CUSTOMERS", ct);
        var shmo = Resolve(cols, "SHMO") ?? throw new InvalidOperationException("ستون SHMO در جدول CUSTOMERS یافت نشد.");
        var name = Resolve(cols, "MONAME", "Name", "CusName");
        var phone = Resolve(cols, "cell", "tell1", "tell2");
        var phone2 = Resolve(cols, "tell1", "tell2");
        var phone3 = Resolve(cols, "tell2");
        if (string.Equals(phone3, phone2, StringComparison.OrdinalIgnoreCase)) phone3 = null;
        var address = Resolve(cols, "address", "Address", "adr", "addr", "manzel");
        var balance = Resolve(cols, "man", "Balance", "Mandeh");
        var vis = Resolve(cols, "vis_rdf", "VisitorID", "visid");

        var select = new List<string> { $"[{shmo}] AS SHMO" };
        select.Add(name is null ? "CAST(NULL AS nvarchar(250)) AS MONAME" : $"TRY_CONVERT(nvarchar(250),[{name}]) AS MONAME");
        select.Add(phone is null ? "CAST(NULL AS nvarchar(100)) AS Phone" : $"TRY_CONVERT(nvarchar(100),[{phone}]) AS Phone");
        select.Add(phone2 is null ? "CAST(NULL AS nvarchar(100)) AS Phone2" : $"TRY_CONVERT(nvarchar(100),[{phone2}]) AS Phone2");
        select.Add(phone3 is null ? "CAST(NULL AS nvarchar(100)) AS Phone3" : $"TRY_CONVERT(nvarchar(100),[{phone3}]) AS Phone3");
        select.Add(address is null ? "CAST(NULL AS nvarchar(500)) AS Address" : $"TRY_CONVERT(nvarchar(500),[{address}]) AS Address");
        select.Add(balance is null ? "CAST(NULL AS decimal(19,2)) AS Balance" : $"TRY_CONVERT(decimal(19,2),[{balance}]) AS Balance");
        select.Add(vis is null ? "CAST(NULL AS int) AS vis_rdf" : $"TRY_CONVERT(int,[{vis}]) AS vis_rdf");

        var predicates = new List<string>();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var parts = new List<string>();
            foreach (var col in new[] { name, phone, phone2, phone3, address })
                if (col is not null) parts.Add($"TRY_CONVERT(nvarchar(500),[{col}]) LIKE N'%' + @s + N'%'");
            parts.Add($"TRY_CONVERT(nvarchar(100),[{shmo}]) LIKE N'%' + @s + N'%'");
            predicates.Add("(" + string.Join(" OR ", parts) + ")");
        }
        if (visitorId.HasValue && vis is not null)
            predicates.Add($"TRY_CONVERT(int,[{vis}])=@v");

        var sql = $"SELECT TOP (2000) {string.Join(",", select)} FROM dbo.[CUSTOMERS]" +
                  (predicates.Count > 0 ? " WHERE " + string.Join(" AND ", predicates) : "") +
                  " ORDER BY MONAME, SHMO;";
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 45 };
        if (!string.IsNullOrWhiteSpace(search)) cmd.Parameters.Add("@s", System.Data.SqlDbType.NVarChar, 250).Value = search;
        if (visitorId.HasValue && vis is not null) cmd.Parameters.Add("@v", System.Data.SqlDbType.Int).Value = visitorId.Value;

        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<CustomerRow>();
        var n = 0;
        while (await r.ReadAsync(ct))
        {
            n++;
            list.Add(new CustomerRow(
                r.IsDBNull(0) ? null : r.GetValue(0),
                r.IsDBNull(1) ? null : r.GetString(1),
                r.IsDBNull(2) ? null : r.GetString(2),
                r.IsDBNull(3) ? null : r.GetString(3),
                r.IsDBNull(4) ? null : r.GetString(4),
                r.IsDBNull(5) ? null : r.GetString(5),
                r.IsDBNull(6) ? null : Convert.ToDecimal(r.GetValue(6)),
                r.IsDBNull(7) ? null : Convert.ToInt32(r.GetValue(7)), n));
        }
        return list;
    }

    public async Task<IReadOnlyList<ProductRow>> ProductsAsync(
        ConnectionProfile p, string user, string password, string? search,
        CancellationToken ct = default)
    {
        await using var c = factory.Create(p, user, password);
        await c.OpenAsync(ct);
        var cols = await ColumnsAsync(c, "inventory", ct);
        var shka = Resolve(cols, "shka", "SHKA") ?? throw new InvalidOperationException("ستون SHKA در جدول inventory یافت نشد.");
        var name = Resolve(cols, "naka", "Name", "KalaName");
        var code = Resolve(cols, "StuffCode", "Code", "Barcode", "KalaCode");
        var price = Resolve(cols, "FinalSalePrice", "SalePrice", "Price");
        var stock = Resolve(cols, "Mojoodi", "mojoodi", "Stock", "Qty", "tedad", "Tedad", "inventorycount");
        var variety = Resolve(cols, "VarietyID", "variety_rdf", "Variety", "group_rdf");

        // Optional real sales aggregation. It is enabled only when the live schema contains
        // a recognizable product key + amount/quantity in subsailfact; otherwise zeros are used.
        var salesCols = await ColumnsIfExistsAsync(c, "subsailfact", ct);
        var salesKey = Resolve(salesCols, "shka", "SHKA", "StuffCode", "KalaID", "kala_rdf", "ProductID");
        var salesAmount = Resolve(salesCols, "all", "mablagh", "Mablagh", "Total", "total", "TotalPrice", "amount");
        var salesQty = Resolve(salesCols, "tedad", "Tedad", "qty", "quantity", "Number", "count");

        var select = new List<string> { $"i.[{shka}] AS shka" };
        select.Add(name is null ? "CAST(NULL AS nvarchar(250)) AS naka" : $"TRY_CONVERT(nvarchar(250),i.[{name}]) AS naka");
        select.Add(code is null ? "CAST(NULL AS nvarchar(100)) AS StuffCode" : $"TRY_CONVERT(nvarchar(100),i.[{code}]) AS StuffCode");
        select.Add(price is null ? "CAST(NULL AS decimal(19,2)) AS Price" : $"TRY_CONVERT(decimal(19,2),i.[{price}]) AS Price");
        select.Add(stock is null ? "CAST(NULL AS decimal(19,3)) AS Stock" : $"TRY_CONVERT(decimal(19,3),i.[{stock}]) AS Stock");
        select.Add(variety is null ? "CAST(NULL AS nvarchar(100)) AS VarietyID" : $"TRY_CONVERT(nvarchar(100),i.[{variety}]) AS VarietyID");
        if (salesKey is not null && (salesAmount is not null || salesQty is not null))
        {
            var amountExpr = salesAmount is null ? "0" : $"ISNULL(TRY_CONVERT(decimal(19,2),s.[{salesAmount}]),0)";
            var qtyExpr = salesQty is null ? "0" : $"ISNULL(TRY_CONVERT(decimal(19,3),s.[{salesQty}]),0)";
            select.Add($"ISNULL((SELECT SUM({amountExpr}) FROM dbo.[subsailfact] s WHERE TRY_CONVERT(nvarchar(100),s.[{salesKey}]) = TRY_CONVERT(nvarchar(100),i.[{shka}])),0) AS SalesAmount");
            select.Add($"ISNULL((SELECT SUM({qtyExpr}) FROM dbo.[subsailfact] s WHERE TRY_CONVERT(nvarchar(100),s.[{salesKey}]) = TRY_CONVERT(nvarchar(100),i.[{shka}])),0) AS SalesQuantity");
        }
        else
        {
            select.Add("CAST(0 AS decimal(19,2)) AS SalesAmount");
            select.Add("CAST(0 AS decimal(19,3)) AS SalesQuantity");
        }

        var predicates = new List<string>();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var parts = new List<string>();
            if (name is not null) parts.Add($"TRY_CONVERT(nvarchar(250),i.[{name}]) LIKE N'%' + @s + N'%'");
            if (code is not null) parts.Add($"TRY_CONVERT(nvarchar(100),i.[{code}]) LIKE N'%' + @s + N'%'");
            parts.Add($"TRY_CONVERT(nvarchar(100),i.[{shka}]) LIKE N'%' + @s + N'%'");
            predicates.Add("(" + string.Join(" OR ", parts) + ")");
        }

        var sql = $"SELECT TOP (1000) {string.Join(",", select)} FROM dbo.[inventory] i" +
                  (predicates.Count > 0 ? " WHERE " + string.Join(" AND ", predicates) : "") +
                  " ORDER BY naka, shka;";
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 60 };
        if (!string.IsNullOrWhiteSpace(search)) cmd.Parameters.Add("@s", System.Data.SqlDbType.NVarChar, 250).Value = search;

        await using var r = await cmd.ExecuteReaderAsync(ct);
        var list = new List<ProductRow>();
        var n = 0;
        while (await r.ReadAsync(ct))
        {
            n++;
            list.Add(new ProductRow(
                r.IsDBNull(0) ? null : r.GetValue(0),
                r.IsDBNull(1) ? null : r.GetString(1),
                r.IsDBNull(2) ? null : r.GetString(2),
                r.IsDBNull(3) ? null : Convert.ToDecimal(r.GetValue(3)),
                r.IsDBNull(4) ? null : Convert.ToDecimal(r.GetValue(4)),
                r.IsDBNull(6) ? 0 : Convert.ToDecimal(r.GetValue(6)),
                r.IsDBNull(7) ? 0 : Convert.ToDecimal(r.GetValue(7)),
                r.IsDBNull(5) ? null : r.GetValue(5), n));
        }
        return list;
    }

    static async Task<HashSet<string>> ColumnsIfExistsAsync(SqlConnection c, string table, CancellationToken ct)
    {
        try { return await ColumnsAsync(c, table, ct); }
        catch { return new HashSet<string>(StringComparer.OrdinalIgnoreCase); }
    }

    static async Task<HashSet<string>> ColumnsAsync(SqlConnection c, string table, CancellationToken ct)
    {
        const string sql = "SELECT c.name FROM sys.columns c JOIN sys.tables t ON t.object_id=c.object_id JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE s.name=N'dbo' AND t.name=@t ORDER BY c.column_id";
        await using var cmd = new SqlCommand(sql, c);
        cmd.Parameters.Add("@t", System.Data.SqlDbType.NVarChar, 128).Value = table;
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        while (await r.ReadAsync(ct)) set.Add(r.GetString(0));
        return set;
    }

    static string? Resolve(HashSet<string> cols, params string[] candidates) => candidates.FirstOrDefault(cols.Contains);
}
