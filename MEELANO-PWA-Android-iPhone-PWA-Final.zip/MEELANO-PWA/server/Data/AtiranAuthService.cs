using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

public sealed class AtiranAuthService(AtiranConnectionFactory factory)
{
    public async Task<LoginResult> LoginAsync(
        ConnectionProfile profile,
        string dbUser,
        string dbPassword,
        string atiranUser,
        string atiranPassword,
        CancellationToken ct = default)
    {
        await using var connection = factory.Create(profile, dbUser, dbPassword);
        await connection.OpenAsync(ct);

        // Atiran has two real authentication stores in the validated schema:
        // visitors.Username/Password and sys_users.user_name/user_password.
        // Passwords must not be guessed or re-hashed by the client.
        const string visitorSql = @"
SELECT TOP (1)
    v.vis_rdf,
    v.vis_name,
    v.UserID
FROM dbo.visitors AS v
WHERE v.Username = @u
  AND v.Password = @pw
  AND (v.active = '1' OR v.active = 'Y' OR v.active = 'y')
ORDER BY v.vis_rdf;";

        await using (var visitorCommand = new SqlCommand(visitorSql, connection))
        {
            visitorCommand.Parameters.Add("@u", System.Data.SqlDbType.NVarChar, 100).Value = atiranUser;
            visitorCommand.Parameters.Add("@pw", System.Data.SqlDbType.NVarChar, 100).Value = atiranPassword;
            await using var reader = await visitorCommand.ExecuteReaderAsync(ct);
            if (await reader.ReadAsync(ct))
            {
                var visitorId = reader.GetInt32(0);
                var visitorName = reader.IsDBNull(1) ? atiranUser : reader.GetString(1);
                int? userId = reader.IsDBNull(2) ? null : reader.GetInt32(2);
                return new(true, "ورود موفق؛ حساب ویزیتور Atiran شناسایی شد.", userId, visitorId, visitorName);
            }
        }

        // sys_users.user_password is VARBINARY(50) in the real schema.
        // Atiran's setup script stores plain password bytes (e.g. CAST('1' AS VARBINARY)),
        // therefore comparing CONVERT(varchar, user_password) is the compatible read-only check.
        const string userSql = @"
SELECT TOP (1)
    u.user_id,
    u.user_name,
    sv.shvis
FROM dbo.sys_users AS u
LEFT JOIN dbo.sys_vis AS sv ON sv.UserID = u.user_id
LEFT JOIN dbo.visitors AS v ON v.vis_rdf = sv.shvis
WHERE u.user_name = @u
  AND CONVERT(varchar(100), u.user_password) = @pw
  AND ISNULL(u.active, 1) = 1
  AND ISNULL(u.IsLocked, 0) = 0
  AND (v.active IS NULL OR v.active IN ('1','Y','y'))
ORDER BY CASE WHEN sv.shvis IS NULL THEN 1 ELSE 0 END, sv.SysID;";

        await using (var userCommand = new SqlCommand(userSql, connection))
        {
            userCommand.Parameters.Add("@u", System.Data.SqlDbType.VarChar, 80).Value = atiranUser;
            userCommand.Parameters.Add("@pw", System.Data.SqlDbType.VarChar, 100).Value = atiranPassword;
            await using var reader = await userCommand.ExecuteReaderAsync(ct);
            if (await reader.ReadAsync(ct))
            {
                var userId = reader.GetInt32(0);
                var userName = reader.IsDBNull(1) ? atiranUser : reader.GetString(1);
                int? visitorId = reader.IsDBNull(2) ? null : reader.GetInt32(2);
                return new(true, visitorId is null
                    ? "ورود موفق؛ حساب کاربری Atiran شناسایی شد."
                    : "ورود موفق و محدوده Visitor شناسایی شد.", userId, visitorId, userName);
            }
        }

        return new(false, "نام کاربری/رمز در مخزن visitors یا sys_users با ساختار واقعی Atiran تطبیق پیدا نکرد. رمز را عیناً و بدون فاصله ابتدا/انتها وارد کنید.", null, null, null);
    }
}
