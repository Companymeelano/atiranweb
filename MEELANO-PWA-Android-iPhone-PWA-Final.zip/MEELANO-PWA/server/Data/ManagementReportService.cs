using System.Data;
using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

namespace Atiran.Management.Data;

public sealed record ManagementTrendPoint(string Label, decimal Value);
public sealed record ManagementCustomerInsight(object? Shmo, string Name, decimal Amount, string Detail);

public sealed record ManagementReportSnapshot(
    long Customers,
    long Products,
    long SalesDocuments,
    decimal SalesTotal,
    long ReceivableChecks,
    decimal ReceivableTotal,
    long PayableChecks,
    decimal PayableTotal,
    IReadOnlyList<ManagementTrendPoint> SalesTrend,
    IReadOnlyList<ManagementCustomerInsight> LargestDebtors,
    IReadOnlyList<ManagementCustomerInsight> NoPurchaseCustomers,
    long NoPurchaseCustomerCount,
    IReadOnlyList<ManagementCustomerInsight> TopBuyers,
    DateTime GeneratedAt);

/// <summary>
/// Read-only executive analytics. Optional reports are enabled only when the
/// live schema contains the columns required for that report.
/// </summary>
public sealed class ManagementReportService(AtiranConnectionFactory factory)
{
    public async Task<ManagementReportSnapshot> LoadAsync(ConnectionProfile profile, string user, string password, int? visitorId, CancellationToken ct = default)
    {
        await using var connection = factory.Create(profile, user, password);
        await connection.OpenAsync(ct);

        var customerCols = await ColumnsAsync(connection, "CUSTOMERS", ct);
        var salesCols = await ColumnsAsync(connection, "sailfact", ct);

        var customers = await CountAsync(connection, "CUSTOMERS", visitorId, customerCols, "vis_rdf", ct);
        var products = await ScalarLongAsync(connection, "SELECT COUNT_BIG(1) FROM dbo.inventory;", null, ct);
        var salesDocuments = await CountSalesAsync(connection, visitorId, salesCols, ct);
        var salesTotal = await SalesTotalAsync(connection, visitorId, salesCols, ct);

        var getCols = await ColumnsAsync(connection, "getchk", ct);
        var putCols = await ColumnsAsync(connection, "putchk", ct);
        var receivableChecks = await CheckCountAsync(connection, "getchk", "getchkmab", customerCols, getCols, visitorId, ct);
        var receivableTotal = await CheckAmountAsync(connection, "getchk", "getchkmab", customerCols, getCols, visitorId, ct);
        var payableChecks = await CheckCountAsync(connection, "putchk", "putchkmab", customerCols, putCols, visitorId, ct);
        var payableTotal = await CheckAmountAsync(connection, "putchk", "putchkmab", customerCols, putCols, visitorId, ct);

        var trend = await LoadSalesTrendAsync(connection, visitorId, salesCols, ct);
        var largestDebtors = await LoadLargestDebtorsAsync(connection, customerCols, visitorId, ct);
        var noPurchase = await LoadNoPurchaseAsync(connection, customerCols, salesCols, visitorId, ct);
        var noPurchaseCount = await CountNoPurchaseAsync(connection, customerCols, salesCols, visitorId, ct);
        var topBuyers = await LoadTopBuyersAsync(connection, customerCols, salesCols, visitorId, ct);

        return new ManagementReportSnapshot(customers, products, salesDocuments, salesTotal,
            receivableChecks, receivableTotal, payableChecks, payableTotal, trend,
            largestDebtors, noPurchase, noPurchaseCount, topBuyers, DateTime.Now);
    }

    async Task<long> CountAsync(SqlConnection c, string table, int? visitorId, HashSet<string> cols, string visitorColumn, CancellationToken ct)
    {
        var where = "";
        if (visitorId.HasValue && cols.Contains(visitorColumn)) where = $" WHERE TRY_CONVERT(int,[{visitorColumn}])=@vis";
        return await ScalarLongAsync(c, $"SELECT COUNT_BIG(1) FROM dbo.[{table}]{where};", visitorId, ct);
    }

    async Task<long> CountSalesAsync(SqlConnection c, int? visitorId, HashSet<string> cols, CancellationToken ct)
    {
        if (!cols.Contains("active")) return 0;
        var where = "WHERE [active] = 't'";
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where += " AND TRY_CONVERT(int,[vis_rdf])=@vis";
        return await ScalarLongAsync(c, $"SELECT COUNT_BIG(1) FROM dbo.sailfact {where};", visitorId, ct);
    }

    async Task<decimal> SalesTotalAsync(SqlConnection c, int? visitorId, HashSet<string> cols, CancellationToken ct)
    {
        if (!cols.Contains("all")) return 0m;
        var where = cols.Contains("active") ? "WHERE [active] = 't'" : "";
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where += (where.Length == 0 ? "WHERE" : " AND") + " TRY_CONVERT(int,[vis_rdf])=@vis";
        return await ScalarDecimalAsync(c, $"SELECT ISNULL(SUM(TRY_CONVERT(decimal(19,2),[all])),0) FROM dbo.sailfact {where};", visitorId, ct);
    }

    async Task<long> CheckCountAsync(SqlConnection c, string table, string amountColumn, HashSet<string> customerCols, HashSet<string> checkCols, int? visitorId, CancellationToken ct)
    {
        if (!checkCols.Contains("shmo")) return 0;
        var sql = "SELECT COUNT_BIG(1) FROM dbo.[" + table + "]";
        if (visitorId.HasValue && customerCols.Contains("SHMO") && customerCols.Contains("vis_rdf"))
            sql += " x WHERE EXISTS (SELECT 1 FROM dbo.CUSTOMERS c WHERE c.SHMO=x.shmo AND TRY_CONVERT(int,c.vis_rdf)=@vis)";
        sql += ";";
        return await ScalarLongAsync(c, sql, visitorId, ct);
    }

    async Task<decimal> CheckAmountAsync(SqlConnection c, string table, string amountColumn, HashSet<string> customerCols, HashSet<string> checkCols, int? visitorId, CancellationToken ct)
    {
        if (!checkCols.Contains(amountColumn)) return 0m;
        var sql = "SELECT ISNULL(SUM(TRY_CONVERT(decimal(19,2),x.[" + amountColumn + "])),0) FROM dbo.[" + table + "] x";
        if (visitorId.HasValue && customerCols.Contains("SHMO") && customerCols.Contains("vis_rdf"))
            sql += " WHERE EXISTS (SELECT 1 FROM dbo.CUSTOMERS c WHERE c.SHMO=x.shmo AND TRY_CONVERT(int,c.vis_rdf)=@vis)";
        sql += ";";
        return await ScalarDecimalAsync(c, sql, visitorId, ct);
    }

    async Task<IReadOnlyList<ManagementCustomerInsight>> LoadLargestDebtorsAsync(SqlConnection c, HashSet<string> cols, int? visitorId, CancellationToken ct)
    {
        if (!cols.Contains("SHMO") || !cols.Contains("man")) return Array.Empty<ManagementCustomerInsight>();
        var name = cols.Contains("MONAME") ? "TRY_CONVERT(nvarchar(250),[MONAME])" : "N'بدون نام'";
        var where = "WHERE TRY_CONVERT(decimal(19,2),[man]) > 0";
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where += " AND TRY_CONVERT(int,[vis_rdf])=@vis";
        var sql = $"SELECT TOP(15) [SHMO], {name}, TRY_CONVERT(decimal(19,2),[man]) FROM dbo.CUSTOMERS {where} ORDER BY TRY_CONVERT(decimal(19,2),[man]) DESC, {name};";
        return await ReadInsightsAsync(c, sql, visitorId, "بدهکار با مانده بالا", ct);
    }

    async Task<IReadOnlyList<ManagementCustomerInsight>> LoadNoPurchaseAsync(SqlConnection c, HashSet<string> customerCols, HashSet<string> salesCols, int? visitorId, CancellationToken ct)
    {
        if (!customerCols.Contains("SHMO") || !salesCols.Contains("shmo")) return Array.Empty<ManagementCustomerInsight>();
        var name = customerCols.Contains("MONAME") ? "TRY_CONVERT(nvarchar(250),c.MONAME)" : "N'بدون نام'";
        var where = "";
        if (visitorId.HasValue && customerCols.Contains("vis_rdf")) where = " AND TRY_CONVERT(int,c.vis_rdf)=@vis";
        var active = salesCols.Contains("active") ? " AND s.active='t'" : "";
        var sql = $@"SELECT TOP(30) c.SHMO,{name},CAST(0 AS decimal(19,2))
FROM dbo.CUSTOMERS c
WHERE NOT EXISTS (SELECT 1 FROM dbo.sailfact s WHERE s.shmo=c.SHMO{active}){where}
ORDER BY {name};";
        return await ReadInsightsAsync(c, sql, visitorId, "بدون خرید ثبت‌شده", ct);
    }


    async Task<long> CountNoPurchaseAsync(SqlConnection c, HashSet<string> customerCols, HashSet<string> salesCols, int? visitorId, CancellationToken ct)
    {
        if (!customerCols.Contains("SHMO") || !salesCols.Contains("shmo")) return 0;
        var where = "";
        if (visitorId.HasValue && customerCols.Contains("vis_rdf")) where = " AND TRY_CONVERT(int,c.vis_rdf)=@vis";
        var active = salesCols.Contains("active") ? " AND s.active='t'" : "";
        var sql = $@"SELECT COUNT_BIG(1) FROM dbo.CUSTOMERS c
WHERE NOT EXISTS (SELECT 1 FROM dbo.sailfact s WHERE s.shmo=c.SHMO{active}){where};";
        return await ScalarLongAsync(c, sql, visitorId, ct);
    }

    async Task<IReadOnlyList<ManagementCustomerInsight>> LoadTopBuyersAsync(SqlConnection c, HashSet<string> customerCols, HashSet<string> salesCols, int? visitorId, CancellationToken ct)
    {
        if (!customerCols.Contains("SHMO") || !salesCols.Contains("shmo") || !salesCols.Contains("all")) return Array.Empty<ManagementCustomerInsight>();
        var name = customerCols.Contains("MONAME") ? "TRY_CONVERT(nvarchar(250),c.MONAME)" : "N'بدون نام'";
        var where = salesCols.Contains("active") ? "WHERE s.active='t'" : "WHERE 1=1";
        if (visitorId.HasValue && customerCols.Contains("vis_rdf")) where += " AND TRY_CONVERT(int,c.vis_rdf)=@vis";
        var sql = $@"SELECT TOP(15) c.SHMO,{name},ISNULL(SUM(TRY_CONVERT(decimal(19,2),s.[all])),0)
FROM dbo.CUSTOMERS c JOIN dbo.sailfact s ON s.shmo=c.SHMO
{where}
GROUP BY c.SHMO,{name}
ORDER BY ISNULL(SUM(TRY_CONVERT(decimal(19,2),s.[all])),0) DESC;";
        return await ReadInsightsAsync(c, sql, visitorId, "بیشترین خرید", ct);
    }

    static async Task<IReadOnlyList<ManagementCustomerInsight>> ReadInsightsAsync(SqlConnection c, string sql, int? visitorId, string detail, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        var list = new List<ManagementCustomerInsight>();
        await using var r = await cmd.ExecuteReaderAsync(ct);
        while (await r.ReadAsync(ct))
            list.Add(new ManagementCustomerInsight(r.IsDBNull(0) ? null : r.GetValue(0), r.IsDBNull(1) ? "بدون نام" : Convert.ToString(r.GetValue(1)) ?? "بدون نام", r.IsDBNull(2) ? 0m : Convert.ToDecimal(r.GetValue(2)), detail));
        return list;
    }

    static async Task<IReadOnlyList<ManagementTrendPoint>> LoadSalesTrendAsync(SqlConnection c, int? visitorId, HashSet<string> cols, CancellationToken ct)
    {
        if (!cols.Contains("date") || !cols.Contains("all")) return Array.Empty<ManagementTrendPoint>();
        var where = cols.Contains("active") ? "WHERE [active] = 't'" : "";
        if (visitorId.HasValue && cols.Contains("vis_rdf")) where += (where.Length == 0 ? "WHERE" : " AND") + " TRY_CONVERT(int,[vis_rdf])=@vis";
        var sql = $"SELECT TOP (12) TRY_CONVERT(nvarchar(40),[date]), SUM(TRY_CONVERT(decimal(19,2),[all])) FROM dbo.sailfact {where} GROUP BY [date] ORDER BY [date] DESC;";
        await using var command = new SqlCommand(sql, c);
        if (sql.Contains("@vis", StringComparison.Ordinal)) command.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        var points = new List<ManagementTrendPoint>();
        await using var reader = await command.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) points.Add(new ManagementTrendPoint(reader.IsDBNull(0) ? "—" : reader.GetString(0), reader.IsDBNull(1) ? 0m : Convert.ToDecimal(reader.GetValue(1))));
        points.Reverse();
        return points;
    }

    static async Task<HashSet<string>> ColumnsAsync(SqlConnection c, string table, CancellationToken ct)
    {
        const string sql = "SELECT c.name FROM sys.columns c JOIN sys.tables t ON t.object_id=c.object_id JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE s.name=N'dbo' AND t.name=@t ORDER BY c.column_id";
        await using var cmd = new SqlCommand(sql, c); cmd.Parameters.Add("@t", SqlDbType.NVarChar, 128).Value = table;
        await using var r = await cmd.ExecuteReaderAsync(ct); var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        while (await r.ReadAsync(ct)) set.Add(r.GetString(0));
        return set;
    }

    static async Task<long> ScalarLongAsync(SqlConnection c, string sql, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        var value = await cmd.ExecuteScalarAsync(ct); return value is null or DBNull ? 0L : Convert.ToInt64(value);
    }

    static async Task<decimal> ScalarDecimalAsync(SqlConnection c, string sql, int? visitorId, CancellationToken ct)
    {
        await using var cmd = new SqlCommand(sql, c) { CommandTimeout = 30 };
        if (sql.Contains("@vis", StringComparison.Ordinal)) cmd.Parameters.Add("@vis", SqlDbType.Int).Value = visitorId!.Value;
        var value = await cmd.ExecuteScalarAsync(ct); return value is null or DBNull ? 0m : Convert.ToDecimal(value);
    }
}
