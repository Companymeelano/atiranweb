# MEELANO PWA — Android / iPhone

این پروژه یک PWA واقعی برای MEELANO است و با مرورگر Android/iPhone نصب می‌شود.

## امنیت اتصال
مرورگر هرگز SQL Server را مستقیم صدا نمی‌زند و هیچ SQL credential داخل JS وجود ندارد. API روی سرور با متغیرهای محیطی زیر به Atiran وصل می‌شود:

- `MEELANO_SQL_INTERNAL_SERVER`
- `MEELANO_SQL_EXTERNAL_SERVER`
- `MEELANO_SQL_INTERNAL_USER`
- `MEELANO_SQL_INTERNAL_PASSWORD`
- `MEELANO_SQL_EXTERNAL_USER`
- `MEELANO_SQL_EXTERNAL_PASSWORD`
- `MEELANO_DB` (پیش‌فرض `Atiran2`)

API ابتدا مسیر داخلی و سپس مسیر بیرونی را برای احراز هویت امتحان می‌کند.

## اجرا روی Windows/IIS یا Kestrel
روی ماشینی که .NET 8 Runtime دارد:

```powershell
dotnet restore
dotnet publish -c Release -o publish
```

سپس متغیرهای محیطی را تنظیم و `Meelano.Pwa.Api.dll` را اجرا کنید. پوشه `wwwroot` همان PWA است.

## نصب روی Android
Chrome/Edge را باز کنید → Install app / Add to Home screen.

## نصب روی iPhone
Safari → Share → Add to Home Screen.

## نکته مهم
برای نصب PWA در محیط واقعی از HTTPS استفاده شود. همچنین API باید در شبکه‌ای قرار بگیرد که خودش قادر به اتصال به SQL Server باشد. گوشی مستقیماً به SQL Server متصل نمی‌شود.
