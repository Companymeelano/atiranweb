using System.Collections.Concurrent;
using System.Data;
using System.Text.Json.Serialization;
using Microsoft.Data.SqlClient;
using Atiran.Management.Data;
using Atiran.Management.Domain;
using Atiran.Management.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<AtiranConnectionFactory>();
builder.Services.AddSingleton<AtiranAuthService>();
builder.Services.AddSingleton<AtiranRepository>();
builder.Services.AddSingleton<DashboardStatsService>();
builder.Services.AddSingleton<ManagementReportService>();
builder.Services.AddSingleton<ExecutiveAnalyticsService>();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

var sessions = new ConcurrentDictionary<string, SessionContext>();
var safeTables = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
{
    "CUSTOMERS","inventory","sailfact","subsailfact","sailfact_pish","subsailfact_pish",
    "buyfact","subbuyfact","getchk","putchk","CheckTypes","visitors","Visit","masir","vis_goals","Variety","UNITS","BANK","kagroup"
};

app.MapGet("/api/session", (HttpContext ctx) =>
{
    if (TrySession(ctx, sessions, out var s))
        return Results.Ok(new { authenticated = true, s.UserName, s.UserId, s.VisitorId });
    return Results.Ok(new { authenticated = false });
});

app.MapPost("/api/login", async (LoginRequest req, HttpContext ctx, AtiranAuthService auth, CancellationToken ct) =>
{
    if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
        return Results.BadRequest(new { message = "نام کاربری و رمز عبور الزامی است." });

    var routes = ServerSettings.Load();
    LoginResult? login = null;
    Exception? last = null;
    foreach (var route in routes)
    {
        try
        {
            var probe = new ConnectionProfile(route.Server, route.Port, route.Database, false, true);
            var sqlUser = route.SqlUser;
            var sqlPassword = route.SqlPassword;
            if (string.IsNullOrWhiteSpace(sqlUser)) continue;
            login = await auth.LoginAsync(probe, sqlUser, sqlPassword, req.Username.Trim(), req.Password, ct);
            if (login.Success)
            {
                var token = Guid.NewGuid().ToString("N");
                sessions[token] = new SessionContext(token, probe, sqlUser, sqlPassword, login.UserId, login.VisitorId, login.UserName ?? req.Username.Trim(), DateTimeOffset.UtcNow);
                ctx.Response.Cookies.Append("meelano_session", token, new CookieOptions { HttpOnly = true, SameSite = SameSiteMode.Lax, Secure = ctx.Request.IsHttps, MaxAge = TimeSpan.FromHours(8), IsEssential = true });
                return Results.Ok(new { authenticated = true, userName = login.UserName ?? req.Username.Trim(), userId = login.UserId, visitorId = login.VisitorId, message = "کاربر با موفقیت وارد شد" });
            }
        }
        catch (Exception ex) { last = ex; }
    }
    return Results.Unauthorized();
});

app.MapPost("/api/logout", (HttpContext ctx) =>
{
    if (ctx.Request.Cookies.TryGetValue("meelano_session", out var t)) sessions.TryRemove(t!, out _);
    ctx.Response.Cookies.Delete("meelano_session");
    return Results.Ok(new { ok = true });
});

app.MapGet("/api/dashboard", async (HttpContext ctx, DashboardStatsService stats, ExecutiveAnalyticsService analytics, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    try
    {
        var metrics = await stats.LoadAsync(s.Profile, s.SqlUser, s.SqlPassword, s.VisitorId, ct);
        var a = await analytics.LoadAsync(s.Profile, s.SqlUser, s.SqlPassword, s.VisitorId, ct);
        return Results.Ok(new { kpis = metrics.Select(x => new { title=x.Title, value=x.Value, available=x.Available }), analytics = AnalyticsDto(a) });
    }
    catch(Exception ex){ return Results.Problem("بارگذاری داشبورد انجام نشد: "+ex.Message); }
});

app.MapGet("/api/customers", async (string? search, AtiranRepository repo, HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    var rows = await repo.CustomersAsync(s.Profile, s.SqlUser, s.SqlPassword, s.VisitorId, search, ct);
    return Results.Ok(rows.Select(r => new { shmo=r.Shmo, name=r.Name, phone=r.Phone, phone2=r.Phone2, phone3=r.Phone3, address=r.Address, balance=r.Balance, visitorId=r.VisitorId, rowNumber=r.RowNumber }));
});

app.MapGet("/api/products", async (string? search, AtiranRepository repo, HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    var rows = await repo.ProductsAsync(s.Profile, s.SqlUser, s.SqlPassword, search, ct);
    return Results.Ok(rows.Select(r => new { shka=r.Shka, name=r.Name, code=r.Code, price=r.Price, stock=r.Stock, salesAmount=r.SalesAmount, salesQuantity=r.SalesQuantity, varietyId=r.VarietyId, rowNumber=r.RowNumber }));
});

app.MapGet("/api/analytics", async (ExecutiveAnalyticsService analytics, HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    var a = await analytics.LoadAsync(s.Profile, s.SqlUser, s.SqlPassword, s.VisitorId, ct);
    return Results.Ok(AnalyticsDto(a));
});

app.MapGet("/api/daily", async (ExecutiveAnalyticsService analytics, string? salesDate, string? purchaseDate, HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    var a = await analytics.LoadDailyAsync(s.Profile, s.SqlUser, s.SqlPassword, s.VisitorId, salesDate, purchaseDate, ct);
    return Results.Ok(new
    {
        a.SalesDate, a.SalesTotal, a.SalesDiscount, a.SalesTax, a.SalesReceived, a.SalesDocuments, a.SalesCustomers, a.SalesItems,
        SalesDocumentsRows=a.SalesDocumentsRows, SalesItemsRows=a.SalesItemsRows,
        a.PurchaseDate, a.PurchaseTotal, a.PurchaseDiscount, a.PurchaseTax, a.PurchasePaid, a.PurchaseDocuments, a.PurchaseSuppliers, a.PurchaseItems,
        PurchaseDocumentsRows=a.PurchaseDocumentsRows, PurchaseItemsRows=a.PurchaseItemsRows, a.GeneratedAt
    });
});

app.MapGet("/api/table/{table}", async (string table, string? q, int? page, int? pageSize, HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    if (!safeTables.Contains(table)) return Results.BadRequest(new { message="این جدول برای نمایش موبایلی مجاز نیست." });
    try
    {
        await using var c = new AtiranConnectionFactory().Create(s.Profile, s.SqlUser, s.SqlPassword);
        await c.OpenAsync(ct);
        var cols = await GetColumns(c, table, ct);
        var safeCols = cols.Where(x => !IsSensitiveColumn(x)).ToList();
        if (safeCols.Count == 0) return Results.Ok(new { columns = Array.Empty<string>(), total = 0L, page = page ?? 1, pageSize = 0, rows = Array.Empty<object>() });
        var take = Math.Clamp(pageSize ?? 150, 1, 500);
        var skip = Math.Max(0, ((page ?? 1) - 1) * take);
        var searchable = safeCols.Where(x=>x.Contains("name",StringComparison.OrdinalIgnoreCase)||x.Contains("code",StringComparison.OrdinalIgnoreCase)||x.Contains("shmo",StringComparison.OrdinalIgnoreCase)||x.Contains("date",StringComparison.OrdinalIgnoreCase)).Take(8).ToList();
        var columnSql = string.Join(",", safeCols.Select(x => $"[{x}]"));
        var where = string.Empty;
        if (!string.IsNullOrWhiteSpace(q) && searchable.Count>0)
            where = " WHERE ("+string.Join(" OR ", searchable.Select(x=>$"TRY_CONVERT(nvarchar(500),[{x}]) LIKE N'%' + @q + N'%'))+")";
        var countSql=$"SELECT COUNT_BIG(1) FROM dbo.[{table}]"+where+";";
        await using var countCmd=new SqlCommand(countSql,c);
        if(!string.IsNullOrWhiteSpace(q)) countCmd.Parameters.Add("@q",SqlDbType.NVarChar,250).Value=q;
        var total=Convert.ToInt64(await countCmd.ExecuteScalarAsync(ct)??0);
        var sql=$"SELECT * FROM (SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) rn,{columnSql} FROM dbo.[{table}]"+where+") x WHERE rn>@skip AND rn<=@take ORDER BY rn;";
        await using var cmd=new SqlCommand(sql,c);
        if(!string.IsNullOrWhiteSpace(q)) cmd.Parameters.Add("@q",SqlDbType.NVarChar,250).Value=q;
        cmd.Parameters.Add("@skip",SqlDbType.Int).Value=skip;cmd.Parameters.Add("@take",SqlDbType.Int).Value=skip+take;
        await using var rd=await cmd.ExecuteReaderAsync(ct);
        var result=new List<Dictionary<string,object?>>();
        while(await rd.ReadAsync(ct)){
            var row=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase);
            for(int i=0;i<rd.FieldCount;i++){var n=rd.GetName(i);if(n.Equals("rn",StringComparison.OrdinalIgnoreCase))continue;row[n]=rd.IsDBNull(i)?null:JsonSafe(rd.GetValue(i));}
            result.Add(row);
        }
        return Results.Ok(new { columns=safeCols, total, page=page??1, pageSize=take, rows=result });
    }
    catch(Exception ex){return Results.Problem(ex.Message);}
});

app.MapGet("/api/schema", async (HttpContext ctx, CancellationToken ct) =>
{
    if (!RequireSession(ctx, sessions, out var s, out var fail)) return fail;
    await using var c = new AtiranConnectionFactory().Create(s.Profile, s.SqlUser, s.SqlPassword); await c.OpenAsync(ct);
    var list=new List<object>();
    const string sql="SELECT t.name, COUNT(c.column_id) column_count, CASE WHEN EXISTS(SELECT 1 FROM sys.indexes i WHERE i.object_id=t.object_id AND i.is_primary_key=1) THEN 1 ELSE 0 END has_pk, CASE WHEN EXISTS(SELECT 1 FROM sys.foreign_keys f WHERE f.parent_object_id=t.object_id OR f.referenced_object_id=t.object_id) THEN 1 ELSE 0 END has_fk FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id LEFT JOIN sys.columns c ON c.object_id=t.object_id WHERE s.name=N'dbo' GROUP BY t.object_id,t.name ORDER BY t.name;";
    await using var cmd=new SqlCommand(sql,c); await using var rd=await cmd.ExecuteReaderAsync(ct); while(await rd.ReadAsync(ct)) list.Add(new { table=rd.GetString(0), columns=rd.GetInt32(1), hasPrimaryKey=rd.GetInt32(2)==1, hasForeignKey=rd.GetInt32(3)==1, safe=safeTables.Contains(rd.GetString(0)) });
    return Results.Ok(list);
});

app.Run();

static object AnalyticsDto(ExecutiveAnalyticsSnapshot a) => new {
    weeklySales=a.WeeklySales.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    monthlyPurchaseSales=a.MonthlyPurchaseSales.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    checkStatuses=a.CheckStatuses.Select(x=>new{label=x.Label,series=x.Series,count=x.Count,amount=x.Amount}),
    topCustomers=a.TopCustomers.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    debtAging=a.DebtAging.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    monthlyProfit=a.MonthlyProfit.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    banks=a.Banks.Select(x=>new{label=x.Label,balance=x.Balance,inflow=x.Inflow,outflow=x.Outflow}),
    categoryShare=a.CategoryShare.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    customerGrowth=a.CustomerGrowth.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    netMargin=a.NetMargin.Select(x=>new{label=x.Label,value=x.Value,secondaryValue=x.SecondaryValue}),
    latestSalesDate=a.LatestSalesDate,latestPurchaseDate=a.LatestPurchaseDate,generatedAt=a.GeneratedAt
};

static bool TrySession(HttpContext ctx, ConcurrentDictionary<string,SessionContext> sessions, out SessionContext session){session=null!;return ctx.Request.Cookies.TryGetValue("meelano_session",out var token)&&token is not null&&sessions.TryGetValue(token,out session!);}
static bool RequireSession(HttpContext ctx, ConcurrentDictionary<string,SessionContext> sessions, out SessionContext session, out IResult fail){if(!TrySession(ctx,sessions,out session)){fail=Results.Unauthorized();return false;}fail=Results.Ok();return true;}
static async Task<List<string>> GetColumns(SqlConnection c,string table,CancellationToken ct){const string sql="SELECT c.name FROM sys.columns c JOIN sys.tables t ON t.object_id=c.object_id JOIN sys.schemas s ON s.schema_id=t.schema_id WHERE s.name=N'dbo' AND t.name=@t ORDER BY c.column_id";await using var cmd=new SqlCommand(sql,c);cmd.Parameters.Add("@t",SqlDbType.NVarChar,128).Value=table;await using var r=await cmd.ExecuteReaderAsync(ct);var list=new List<string>();while(await r.ReadAsync(ct))list.Add(r.GetString(0));return list;}
static bool IsSensitiveColumn(string name)
{
    var n = name.Trim().ToLowerInvariant();
    return n.Contains("password") || n.Contains("passwd") || n.Contains("pass") || n.Contains("secret") || n.Contains("token") || n.Contains("connectionstring") || n.Contains("accesskey");
}
static object? JsonSafe(object value){if(value is byte[] b)return Convert.ToBase64String(b);if(value is DateTime dt)return dt.ToString("O");if(value is DateTimeOffset dto)return dto.ToString("O");if(value is decimal or double or float or int or long or short or byte or uint or ulong or ushort or sbyte)return Convert.ToString(value,System.Globalization.CultureInfo.InvariantCulture)!;return value;}
record LoginRequest(string Username,string Password);
record SessionContext(string Token,ConnectionProfile Profile,string SqlUser,string SqlPassword,int? UserId,int? VisitorId,string UserName,DateTimeOffset CreatedAt);

static class ServerSettings
{
    public static IEnumerable<(string Server,int Port,string Database,string SqlUser,string SqlPassword)> Load()
    {
        var db=Get("MEELANO_DB","Atiran2");
        yield return (Get("MEELANO_SQL_INTERNAL_SERVER","192.168.1.150"),GetInt("MEELANO_SQL_PORT",1433),db,Get("MEELANO_SQL_INTERNAL_USER",""),Get("MEELANO_SQL_INTERNAL_PASSWORD",""));
        yield return (Get("MEELANO_SQL_EXTERNAL_SERVER","37.143.147.19"),GetInt("MEELANO_SQL_PORT",1433),db,Get("MEELANO_SQL_EXTERNAL_USER",""),Get("MEELANO_SQL_EXTERNAL_PASSWORD",""));
    }
    static string Get(string n,string d)=>Environment.GetEnvironmentVariable(n)??d;
    static int GetInt(string n,int d)=>int.TryParse(Environment.GetEnvironmentVariable(n),out var x)?x:d;
}
