using Microsoft.Data.SqlClient;
using Atiran.Management.Domain;

namespace Atiran.Management.Infrastructure;

public sealed class AtiranConnectionFactory
{
    public SqlConnection Create(ConnectionProfile profile, string user, string password)
    {
        if (string.IsNullOrWhiteSpace(profile.Server))
            throw new ArgumentException("نشانی سرور خالی است.", nameof(profile));
        if (profile.Port is < 1 or > 65535)
            throw new ArgumentOutOfRangeException(nameof(profile), "پورت اتصال معتبر نیست.");
        if (string.IsNullOrWhiteSpace(user))
            throw new ArgumentException("نام کاربری SQL خالی است.", nameof(user));

        var builder = new SqlConnectionStringBuilder
        {
            // Force TCP so the internal and external profiles behave identically.
            DataSource = $"tcp:{profile.Server},{profile.Port}",
            InitialCatalog = string.IsNullOrWhiteSpace(profile.Database) ? "master" : profile.Database,
            UserID = user,
            Password = password ?? string.Empty,
            Encrypt = profile.Encrypt,
            TrustServerCertificate = profile.TrustServerCertificate,
            ConnectTimeout = 12,
            ConnectRetryCount = 2,
            ConnectRetryInterval = 1,
            ApplicationName = "MEELANO"
        };

        return new SqlConnection(builder.ConnectionString);
    }
}
