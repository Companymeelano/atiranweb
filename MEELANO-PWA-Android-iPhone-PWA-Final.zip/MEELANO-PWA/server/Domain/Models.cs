namespace Atiran.Management.Domain;
public sealed record ConnectionProfile(string Server, int Port, string Database, bool Encrypt, bool TrustServerCertificate);
public sealed record LoginResult(bool Success, string Message, int? UserId, int? VisitorId, string? UserName);
public sealed record VisitorContext(int? UserId, int VisitorId, string? UserName);
public sealed record CustomerRow(object? Shmo, string? Name, string? Phone, string? Phone2, string? Phone3, string? Address, decimal? Balance, int? VisitorId, int RowNumber = 0);
public sealed record ProductRow(object? Shka, string? Name, string? Code, decimal? Price, decimal? Stock, decimal? SalesAmount, decimal? SalesQuantity, object? VarietyId, int RowNumber = 0);
public sealed record DashboardMetrics(int Customers, decimal CustomerBalance, int Products, int Checks, decimal PreInvoiceAmount);
public sealed record SchemaTable(string Schema, string Table, int ColumnCount, bool HasPrimaryKey, bool HasForeignKey);
public sealed record QueryColumn(string Name, Type Type);
